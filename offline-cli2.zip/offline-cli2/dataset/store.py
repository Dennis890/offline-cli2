from __future__ import annotations

import difflib
import json
from collections import defaultdict
from pathlib import Path

from utils.errors import DatasetError
from utils.models import MatchResult
from utils.response_parser import response_to_dataset_steps, slugify, tokenize


class DatasetStore:
    def __init__(self, dataset_path: Path) -> None:
        self.dataset_path = dataset_path
        self._data: dict | None = None
        self._entries: list[dict] = []
        self._token_index: dict[str, set[int]] = {}

    @property
    def entries(self) -> list[dict]:
        self._ensure_loaded()
        return self._entries

    def _ensure_loaded(self) -> None:
        if self._data is not None:
            return

        if not self.dataset_path.exists():
            raise DatasetError(f"Missing dataset file: '{self.dataset_path}'.")

        try:
            self._data = json.loads(self.dataset_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as error:
            raise DatasetError("The Laravel dataset JSON is invalid.") from error

        self._entries = self._data.get("entries", [])
        self._rebuild_index()

    def _rebuild_index(self) -> None:
        index: dict[str, set[int]] = defaultdict(set)

        for idx, entry in enumerate(self._entries):
            tokens = set(tokenize(entry.get("name", "")))
            for keyword in entry.get("keywords", []):
                tokens.update(tokenize(keyword))

            for token in tokens:
                index[token].add(idx)

        self._token_index = dict(index)

    def best_match(self, query: str) -> MatchResult:
        self._ensure_loaded()
        lowered_query = query.lower()
        query_tokens = set(tokenize(query))
        candidate_ids: set[int] = set()

        for token in query_tokens:
            candidate_ids.update(self._token_index.get(token, set()))

        if not candidate_ids:
            candidate_ids = set(range(len(self._entries)))

        best_entry: dict | None = None
        best_score = 0

        for idx in candidate_ids:
            entry = self._entries[idx]
            score = 0
            name = entry.get("name", "").lower()
            if name and name in lowered_query:
                score += 8

            for keyword in entry.get("keywords", []):
                lowered_keyword = keyword.lower()
                keyword_tokens = set(tokenize(lowered_keyword))

                if lowered_keyword in lowered_query:
                    score += 5 + len(keyword_tokens) * 2

                if keyword_tokens and keyword_tokens.issubset(query_tokens):
                    score += len(keyword_tokens) * 5

                score += len(query_tokens & keyword_tokens) * 2

            if score > best_score:
                best_score = score
                best_entry = entry

        return MatchResult(entry=best_entry, score=best_score)

    def search(self, term: str, limit: int = 10) -> list[dict]:
        self._ensure_loaded()
        lowered_term = term.lower()
        ranked: list[tuple[int, dict]] = []

        for entry in self._entries:
            score = 0
            haystack = " ".join([entry.get("name", "")] + entry.get("keywords", []))
            if lowered_term in haystack.lower():
                score += 10

            score += len(set(tokenize(lowered_term)) & set(tokenize(haystack))) * 3
            if score > 0:
                ranked.append((score, entry))

        ranked.sort(key=lambda item: item[0], reverse=True)
        return [entry for _, entry in ranked[:limit]]

    def suggest_commands(self, text: str, limit: int = 5) -> list[str]:
        self._ensure_loaded()
        query_tokens = tokenize(text)
        subject = " ".join(query_tokens[1:]) if len(query_tokens) > 1 else " ".join(query_tokens)
        subject = subject.strip() or text.lower().strip()

        scored: list[tuple[float, str]] = []
        seen: set[str] = set()

        for entry in self._entries:
            candidates = [entry.get("name", "").replace("_", " ").strip()]
            candidates.extend(entry.get("keywords", [])[:4])

            for candidate in candidates:
                if not candidate:
                    continue
                command = f"create {candidate}"
                if command in seen:
                    continue
                seen.add(command)

                ratio = difflib.SequenceMatcher(None, subject, candidate.lower()).ratio()
                token_overlap = len(set(tokenize(subject)) & set(tokenize(candidate)))
                score = ratio + (token_overlap * 0.2)
                if score >= 0.35:
                    scored.append((score, command))

        scored.sort(key=lambda item: item[0], reverse=True)
        return [command for _, command in scored[:limit]]

    def learn_from_response(self, task: str, response_text: str, source: str) -> bool:
        self._ensure_loaded()
        normalized = response_text.strip()
        if not normalized:
            return False

        learned_steps = response_to_dataset_steps(normalized)
        if not learned_steps:
            return False

        learned_hash = self._steps_signature(learned_steps)

        for entry in self._entries:
            if self._entry_signature(entry) == learned_hash:
                return False

        keywords = self._extract_keywords(task)
        new_entry = {
            "name": slugify(task),
            "keywords": keywords,
            "steps": learned_steps,
            "source": source,
            "learned_from": task,
        }

        self._entries.append(new_entry)
        self._data["entries"] = self._entries
        self._rebuild_index()
        self.save()
        return True

    def _extract_keywords(self, task: str) -> list[str]:
        tokens = [token for token in tokenize(task) if len(token) > 2 and token != "laravel"]
        keywords = list(dict.fromkeys(tokens[:8]))
        if not keywords:
            keywords = ["laravel"]
        return keywords

    def _entry_signature(self, entry: dict) -> str:
        return self._steps_signature(entry.get("steps", []))

    def _steps_signature(self, steps: list[dict]) -> str:
        pieces: list[str] = []
        for step in steps:
            code_lines = step.get("code_lines", [])
            code = "\n".join(code_lines) if code_lines else step.get("code", "")
            pieces.append(f"{step.get('file', '')}|{code}|{step.get('explanation', '')}")
        return "\n".join(pieces).strip()

    def save(self) -> None:
        if self._data is None:
            return
        self.dataset_path.parent.mkdir(parents=True, exist_ok=True)
        self.dataset_path.write_text(json.dumps(self._data, indent=2) + "\n", encoding="utf-8")
