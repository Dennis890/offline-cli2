from __future__ import annotations


SUPPORTED_MODES = ("mini", "openai", "claude", "groq", "local")
ACTION_WORDS = {
    "create",
    "build",
    "generate",
    "make",
    "add",
    "fix",
    "update",
    "explain",
    "show",
    "write",
}
BLOCKED_FRAMEWORKS = {
    "react",
    "node",
    "nodejs",
    "express",
    "next.js",
    "nextjs",
    "vue",
    "nuxt",
    "angular",
    "django",
    "flask",
    "fastapi",
    "spring",
    "rails",
    "asp.net",
    ".net",
}
LARAVEL_HINTS = {
    "laravel",
    "php",
    "blade",
    "artisan",
    "eloquent",
    "migration",
    "middleware",
    "controller",
    "route",
    "routes",
    "auth",
    "login",
    "register",
    "crud",
    "validation",
    "api",
    "sanctum",
    "pagination",
    "upload",
}
OFFLINE_KEYWORDS = {
    "offline",
    "local",
    "without internet",
    "without api",
}
COMPLEXITY_KEYWORDS = {
    "sanctum",
    "policy",
    "queue",
    "job",
    "event",
    "listener",
    "service",
    "transaction",
    "exception",
    "observer",
    "notification",
    "scheduler",
    "command",
    "throttle",
    "api version",
}
SIMPLE_INTENTS = {
    "login",
    "register",
    "auth",
    "crud",
    "middleware",
    "validation",
    "upload",
    "pagination",
    "blade",
}
PROMPT_TEMPLATE = """You are a professional Laravel (PHP) expert.

Answer only with Laravel and PHP solutions.
Do not include any other framework.
Keep it beginner friendly and practical.

Give answer in this format:
Step 1: file path
```php
code
```
Explanation: one line

Step 2: file path
```php
code
```
Explanation: one line

Use real Laravel file paths and real Laravel code.

Request: {user_request}
"""
