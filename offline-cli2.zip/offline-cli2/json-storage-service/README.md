# JSON Storage Management Service

A production-ready RESTful API built with Node.js, Express, and TypeScript that uses a JSON file as its core data source.

## Features

- **Full CRUD Operations**: Create, Read, Update, and Delete items.
- **Scalable Architecture**: Controller, Service, and Data Repository layers.
- **Data Consistency**: In-memory mutex locking (`async-mutex`) ensures safe concurrent reads and writes to the JSON file.
- **Validation**: Schema validation using `zod` prevents invalid data insertion.
- **Caching**: Data is loaded into memory on startup and updated in-sync with file writes for lightning-fast reads.
- **Pagination**: The `GET /items` endpoint supports `page` and `limit` query parameters.
- **Automated Backups**: Every write operation creates a timestamped backup of the JSON file in the `data/backups/` directory (configurable).
- **Logging**: All operations and errors are logged with timestamps.
- **Security**: Includes `helmet` for HTTP headers, `cors`, and rate limiting.

## Setup Instructions

1. **Install Dependencies**
   ```bash
   cd e:\offline_ai_combo\json-storage-service
   npm install
   ```

2. **Environment Configuration**
   The `.env` file is already provided. You can modify the port or file paths if needed.

3. **Start the Application**
   - For development (with hot-reload):
     ```bash
     npm run dev
     ```
   - For production:
     ```bash
     npm run build
     npm start
     ```

## API Endpoints

- `GET /health` : Health check
- `GET /api/v1/items` : Get all items (Query params: `page`, `limit`)
- `GET /api/v1/items/:id` : Get item by ID
- `POST /api/v1/items` : Create a new item
- `PUT /api/v1/items/:id` : Update an existing item
- `DELETE /api/v1/items/:id` : Delete an item

Refer to `api-examples.http` for detailed test queries that you can run using the VS Code REST Client.
