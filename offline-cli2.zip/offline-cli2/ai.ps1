$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Check if Python is installed
try {
    $null = Get-Command "python" -ErrorAction Stop
} catch {
    Write-Host "[X] Error: Python is not installed or not found in PATH!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please install Python (from python.org or Windows Store)."
    Write-Host "If you are on a locked college PC, download the 'Windows embeddable package'"
    Write-Host "from python.org, extract it to this folder, and rename python.exe if needed."
    Write-Host ""
    exit 1
}

if ($args.Count -gt 0 -and $args[0] -eq "setup") {
    & python "$ScriptDir\setup.py"
} else {
    & python "$ScriptDir\main.py" $args
}
