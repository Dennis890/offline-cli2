from __future__ import annotations

import io
import os
import shutil
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from assistant import LaravelAssistantCLI
from dataset.store import DatasetStore
from utils.models import CommandRequest


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class LaravelAssistantSmokeTest(unittest.TestCase):
    def setUp(self) -> None:
        self.original_env = {
            "OPENAI_API_KEY": os.environ.get("OPENAI_API_KEY"),
            "ANTHROPIC_API_KEY": os.environ.get("ANTHROPIC_API_KEY"),
            "GROQ_API_KEY": os.environ.get("GROQ_API_KEY"),
        }
        os.environ.pop("OPENAI_API_KEY", None)
        os.environ.pop("ANTHROPIC_API_KEY", None)
        os.environ.pop("GROQ_API_KEY", None)

        self.temp_dir = Path(tempfile.mkdtemp(prefix="laravel_cli_test_"))
        (self.temp_dir / "dataset").mkdir(parents=True, exist_ok=True)
        (self.temp_dir / "local").mkdir(parents=True, exist_ok=True)
        shutil.copy2(PROJECT_ROOT / "dataset" / "mini_ai.json", self.temp_dir / "dataset" / "mini_ai.json")
        self.cli = LaravelAssistantCLI(base_dir=self.temp_dir, working_dir=self.temp_dir, use_color=False)

    def tearDown(self) -> None:
        for key, value in self.original_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _run(self, request: CommandRequest) -> tuple[int, str]:
        stream = io.StringIO()
        with redirect_stdout(stream):
            code = self.cli.run(request)
        return code, stream.getvalue()

    def test_mini_mode_returns_step_format(self) -> None:
        code, output = self._run(CommandRequest(command="run", explicit_mode="mini", task="create login system"))
        self.assertEqual(code, 0)
        self.assertIn("Step 1:", output)
        self.assertIn("Explanation:", output)

    def test_fallback_reaches_mini(self) -> None:
        code, output = self._run(CommandRequest(command="run", explicit_mode="openai", task="create middleware auth"))
        self.assertEqual(code, 0)
        self.assertIn("switching to", output)
        self.assertIn("Step 1:", output)

    def test_cache_is_used_on_repeat_request(self) -> None:
        first = self._run(CommandRequest(command="run", explicit_mode="mini", task="create login system"))
        second = self._run(CommandRequest(command="run", explicit_mode="mini", task="create login system"))

        self.assertEqual(first[0], 0)
        self.assertEqual(second[0], 0)
        self.assertIn("[Cache hit -> mini]", second[1])

    def test_dataset_learning_avoids_duplicate_entries(self) -> None:
        store = DatasetStore(self.temp_dir / "dataset" / "mini_ai.json")
        before_count = len(store.entries)
        response = "\n".join(
            [
                "Step 1: routes/web.php",
                "```php",
                "<?php",
                "Route::get('/health', fn () => 'ok');",
                "```",
                "",
                "Explanation: This route adds a simple Laravel health check.",
            ]
        )

        learned_once = store.learn_from_response("create health route", response, "openai")
        learned_twice = store.learn_from_response("create health route", response, "openai")

        self.assertTrue(learned_once)
        self.assertFalse(learned_twice)
        self.assertEqual(len(store.entries), before_count + 1)


if __name__ == "__main__":
    unittest.main()
