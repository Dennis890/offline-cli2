from __future__ import annotations

import sys
from pathlib import Path

import config
from ai_engines.claude_engine import ClaudeEngine
from ai_engines.groq_engine import GroqEngine
from ai_engines.local_engine import LocalEngine
from ai_engines.mini_engine import MiniEngine
from ai_engines.openai_engine import OpenAIEngine
from dataset.store import DatasetStore
from utils.console import ConsolePrinter
from utils.constants import ACTION_WORDS
from utils.errors import LaravelCLIError, UsageError
from utils.file_actions import FileActionManager
from utils.intent import EngineAvailability, IntentDetector
from utils.models import CommandRequest, EngineResult
from utils.response_parser import (
    contains_blocked_framework,
    normalize_request,
    render_scope_only_response,
)
from utils.state import RuntimeState, sanitize_secret


class LaravelAssistantCLI:
    def __init__(self, base_dir: Path, working_dir: Path | None = None, use_color: bool = True) -> None:
        self.base_dir = base_dir
        self.working_dir = working_dir or Path.cwd()
        self.printer = ConsolePrinter(use_color=use_color)
        self.dataset_store = DatasetStore(base_dir / config.MINI_AI_FILE)
        self.state = RuntimeState(
            base_dir=base_dir,
            cache_dir=config.CACHE_DIR,
            history_file=config.HISTORY_FILE,
            fallback_log_file=config.FALLBACK_LOG_FILE,
            last_output_file=config.LAST_OUTPUT_FILE,
            cache_enabled=config.CACHE_ENABLED,
        )
        self.intent_detector = IntentDetector()
        self.file_actions = FileActionManager(self.working_dir)
        self.engines = {
            "mini": MiniEngine(self.dataset_store),
            "openai": OpenAIEngine(),
            "claude": ClaudeEngine(),
            "groq": GroqEngine(),
            "local": LocalEngine(base_dir),
        }

    def run(self, request: CommandRequest) -> int:
        if request.command == "search":
            results = self.dataset_store.search(request.search_term)
            self.printer.print_search_results(request.search_term, results)
            return 0

        if request.command == "export":
            target = self.working_dir / request.export_path
            try:
                exported_path = self.state.export_last_output(target)
            except FileNotFoundError as error:
                self.printer.error(f"[ERROR] {error}")
                return 1
            self.printer.success(f"Last Laravel answer exported to {exported_path}")
            return 0

        return self._run_generation(request)

    def _run_generation(self, request: CommandRequest) -> int:
        task = normalize_request(request.task)
        if not task:
            raise UsageError("Laravel task is required.")

        blocked_framework = contains_blocked_framework(task)
        if blocked_framework:
            self.printer.print_response(render_scope_only_response(blocked_framework))
            return 0

        match = self.dataset_store.best_match(task)

        if not request.explicit_mode and self._looks_like_unknown_command(task, match.score):
            suggestions = self.dataset_store.suggest_commands(task)
            if suggestions:
                self.printer.warn("Unknown Laravel command or feature.")
                self.printer.print_suggestions(suggestions)
                return 1

        availability = self._availability()
        if request.explicit_mode:
            requested_mode = request.explicit_mode
            chain = self._build_chain(request.explicit_mode)
            auto_mode = False
        else:
            decision = self.intent_detector.choose_mode(
                task=task,
                match=match,
                availability=availability,
                offline_requested=request.offline,
            )
            requested_mode = "auto"
            auto_mode = True
            self.printer.info(f"[Auto mode -> {decision.mode}] {decision.reason}")
            chain = self._build_chain(decision.mode, auto=True)

        cache_bucket = requested_mode if not auto_mode else f"auto:{chain[0]}"
        cache_salt = self._cache_salt(chain[0])
        cached_response = self.state.load_cache(cache_bucket, task, cache_salt)
        if cached_response:
            self.printer.info(f"[Cache hit -> {chain[0]}]")
            self.printer.print_response(cached_response)
            self.state.log_history(requested_mode, chain[0], task, from_cache=True, auto_mode=auto_mode)
            self.state.save_last_output(task, chain[0], cached_response)
            return 0

        result = self._execute_chain(task, chain, requested_mode, auto_mode)
        if result is None:
            self.printer.error("[ERROR] No Laravel engine could complete the request.")
            return 1

        if result.cacheable and (result.mode == chain[0] or config.CACHE_FALLBACK_RESPONSES):
            self.state.save_cache(cache_bucket, task, result.text, self._cache_salt(result.mode))

        self.state.log_history(requested_mode, result.mode, task, from_cache=False, auto_mode=auto_mode)
        self.state.save_last_output(task, result.mode, result.text)
        self.printer.print_response(result.text)

        if config.DATASET_AUTO_LEARN_ENABLED and result.auto_learn:
            learned = self.dataset_store.learn_from_response(task, result.text, result.mode)
            if learned:
                self.printer.info("[Dataset learned] The offline Laravel dataset was updated with this answer.")

        if (request.apply_files or config.PROMPT_TO_APPLY_FILES) and sys.stdin.isatty():
            written_files = self.file_actions.prompt_and_apply(result.text)
            for written_path in written_files:
                self.printer.success(f"Updated file: {written_path}")

        return 0

    def _availability(self) -> EngineAvailability:
        return EngineAvailability(
            openai=self.engines["openai"].is_available(),
            claude=self.engines["claude"].is_available(),
            groq=self.engines["groq"].is_available(),
            local=self.engines["local"].is_available(),
        )

    def _build_chain(self, start_mode: str, auto: bool = False) -> list[str]:
        if start_mode == "openai":
            return ["openai", "claude", "groq", "local", "mini"]
        if start_mode == "claude":
            return ["claude", "groq", "local", "mini"]
        if start_mode == "groq":
            return ["groq", "local", "mini"]
        if start_mode == "local":
            return ["local", "mini"]
        if start_mode == "mini" and auto:
            return ["mini", "openai", "claude", "groq", "local"]
        return ["mini"]

    def _execute_chain(
        self, task: str, chain: list[str], requested_mode: str, auto_mode: bool
    ) -> EngineResult | None:
        last_error: str | None = None

        for index, mode in enumerate(chain):
            engine = self.engines[mode]
            try:
                result = engine.run(task)
                if mode == "mini" and not result.matched and len(chain) > index + 1:
                    next_mode = chain[index + 1]
                    self.printer.warn(f"[Mini dataset miss -> switching to {next_mode}]")
                    self.state.log_fallback("Mini dataset", next_mode, "No strong offline match.")
                    continue
                return result
            except LaravelCLIError as error:
                last_error = sanitize_secret(str(error))
                if len(chain) > index + 1:
                    next_mode = chain[index + 1]
                    self.printer.warn(f"[{mode} failed -> switching to {next_mode}]")
                    self.printer.warn(f"[Reason] {last_error}")
                    self.state.log_fallback(mode, next_mode, last_error)
                    continue
                self.printer.error(f"[ERROR] {last_error}")
                return None

        if last_error:
            self.printer.error(f"[ERROR] {last_error}")
        return None

    def _looks_like_unknown_command(self, task: str, match_score: int) -> bool:
        tokens = task.lower().split()
        if not tokens:
            return False
        if tokens[0] in ACTION_WORDS:
            return False
        return match_score < 8

    def _cache_salt(self, mode: str) -> str:
        if mode == "mini":
            return str(self._safe_mtime(self.base_dir / config.MINI_AI_FILE))
        if mode == "local":
            return "|".join(
                [
                    str(self._safe_mtime(self.base_dir / config.LOCAL_MODEL_PATH)),
                    str(self._safe_mtime(self.base_dir / config.LOCAL_MODEL_FILE)),
                ]
            )
        if mode == "openai":
            return config.OPENAI_MODEL
        if mode == "claude":
            return config.ANTHROPIC_MODEL
        if mode == "groq":
            return config.GROQ_MODEL
        return mode

    def _safe_mtime(self, path: Path) -> int:
        try:
            return path.stat().st_mtime_ns
        except OSError:
            return 0
