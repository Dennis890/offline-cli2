import os
import json
import sys
from pathlib import Path

def setup():
    base_dir = Path(__file__).parent.resolve()
    
    print("\n🚀 Starting Portable AI Setup...")
    
    # Create required directories
    folders = ["cache", "logs", "history", "dataset"]
    for folder in folders:
        folder_path = base_dir / folder
        folder_path.mkdir(exist_ok=True)
        print(f"  ✅ Created/Verified folder: {folder}/")

    # Create config.json if missing
    config_path = base_dir / "config.json"
    if not config_path.exists():
        default_config = {
            "installed_models": [],
            "current_model": None
        }
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(default_config, f, indent=4)
        print("  ✅ Created default config.json")
    else:
        print("  ✅ config.json already exists")

    # Verify dataset exists, if not create a dummy
    dataset_path = base_dir / "dataset" / "mini_ai.json"
    if not dataset_path.exists():
        dummy_data = {
            "entries": [
                {
                    "name": "hello_world",
                    "keywords": ["hello", "hi", "greet"],
                    "steps": [{"file": "demo.py", "explanation": "This is a demo local response."}]
                }
            ]
        }
        with open(dataset_path, "w", encoding="utf-8") as f:
            json.dump(dummy_data, f, indent=4)
        print("  ✅ Created demo dataset/mini_ai.json")
    else:
        print("  ✅ Found existing dataset/mini_ai.json")

    print("\n🎉 Setup complete! You are ready to go.")
    print("Next steps:")
    print("  1. .\\ai install local")
    print("  2. .\\ai use local")
    print("  3. .\\ai ask \"your query here\"\n")

if __name__ == "__main__":
    setup()
