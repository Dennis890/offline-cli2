class LaravelCLIError(Exception):
    """Base application error."""


class UsageError(LaravelCLIError):
    """Raised for invalid CLI usage."""


class DatasetError(LaravelCLIError):
    """Raised for dataset issues."""


class ValidationError(LaravelCLIError):
    """Raised when response validation fails."""


class MiniModeError(LaravelCLIError):
    """Raised when mini mode cannot complete."""


class OpenAIModeError(LaravelCLIError):
    """Raised when OpenAI mode cannot complete."""


class ClaudeModeError(LaravelCLIError):
    """Raised when Claude mode cannot complete."""


class GroqModeError(LaravelCLIError):
    """Raised when Groq mode cannot complete."""


class LocalModeError(LaravelCLIError):
    """Raised when local mode cannot complete."""
