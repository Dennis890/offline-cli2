import { FileRepository } from '../data/file.repository';
import { Item } from '../models/item.schema';
import { config } from '../config/env';
import crypto from 'crypto';

export class StorageService {
  private repository: FileRepository<Item>;

  constructor() {
    this.repository = new FileRepository<Item>(config.dataFilePath);
  }

  public async getAllItems(page: number = 1, limit: number = 10): Promise<{ data: Item[], total: number, page: number, limit: number }> {
    const allItems = await this.repository.findAll();
    
    // Pagination logic
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedItems = allItems.slice(startIndex, endIndex);

    return {
      data: paginatedItems,
      total: allItems.length,
      page,
      limit
    };
  }

  public async getItemById(id: string): Promise<Item | undefined> {
    return await this.repository.findById(id);
  }

  public async createItem(itemData: Omit<Item, 'id' | 'lastUpdated'>): Promise<Item> {
    const newItem: Item = {
      ...itemData,
      id: crypto.randomUUID(),
      lastUpdated: new Date().toISOString()
    };
    return await this.repository.create(newItem);
  }

  public async updateItem(id: string, itemData: Partial<Item>): Promise<Item | null> {
    const updatePayload = {
      ...itemData,
      lastUpdated: new Date().toISOString()
    };
    return await this.repository.update(id, updatePayload);
  }

  public async deleteItem(id: string): Promise<boolean> {
    return await this.repository.delete(id);
  }
}
