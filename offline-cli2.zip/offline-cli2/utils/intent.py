from __future__ import annotations

from dataclasses import dataclass

from .constants import COMPLEXITY_KEYWORDS, OFFLINE_KEYWORDS, SIMPLE_INTENTS
from .models import IntentDecision, MatchResult
from .response_parser import tokenize


@dataclass
class EngineAvailability:
    openai: bool
    claude: bool
    groq: bool
    local: bool


class IntentDetector:
    def choose_mode(
        self,
        task: str,
        match: MatchResult,
        availability: EngineAvailability,
        offline_requested: bool = False,
    ) -> IntentDecision:
        lowered = task.lower()
        tokens = set(tokenize(lowered))
        matched_keywords = [token for token in tokens if token in SIMPLE_INTENTS or token in COMPLEXITY_KEYWORDS]
        complexity_score = sum(1 for token in COMPLEXITY_KEYWORDS if token in lowered)

        if offline_requested or any(keyword in lowered for keyword in OFFLINE_KEYWORDS):
            chosen = "local" if availability.local else "mini"
            return IntentDecision(
                mode=chosen,
                reason="Offline wording detected in the request.",
                intent=matched_keywords[0] if matched_keywords else "offline",
                confidence=max(match.score, 20),
                keywords=matched_keywords,
            )

        if match.entry and match.score >= 14 and complexity_score == 0:
            return IntentDecision(
                mode="mini",
                reason="The request matches a strong offline Laravel feature.",
                intent=match.entry.get("name", "laravel_feature"),
                confidence=match.score,
                keywords=matched_keywords,
            )

        if complexity_score > 0:
            if availability.openai:
                return IntentDecision(
                    mode="openai",
                    reason="Complex Laravel logic detected, so the assistant will try the smartest cloud engine first.",
                    intent=matched_keywords[0] if matched_keywords else "complex_laravel_task",
                    confidence=match.score + complexity_score * 3,
                    keywords=matched_keywords,
                )
            if availability.claude:
                return IntentDecision(
                    mode="claude",
                    reason="Complex Laravel logic detected, so the assistant will try Claude first.",
                    intent=matched_keywords[0] if matched_keywords else "complex_laravel_task",
                    confidence=match.score + complexity_score * 3,
                    keywords=matched_keywords,
                )
            if availability.groq:
                return IntentDecision(
                    mode="groq",
                    reason="Complex Laravel logic detected, so the assistant will try Groq first.",
                    intent=matched_keywords[0] if matched_keywords else "complex_laravel_task",
                    confidence=match.score + complexity_score * 3,
                    keywords=matched_keywords,
                )

        if availability.openai:
            return IntentDecision(
                mode="openai",
                reason="The request looks more custom than the offline dataset, so cloud reasoning is preferred.",
                intent=matched_keywords[0] if matched_keywords else "custom_laravel_task",
                confidence=max(match.score, 10),
                keywords=matched_keywords,
            )

        if availability.claude:
            return IntentDecision(
                mode="claude",
                reason="Claude is available and the request looks more custom than the offline dataset.",
                intent=matched_keywords[0] if matched_keywords else "custom_laravel_task",
                confidence=max(match.score, 10),
                keywords=matched_keywords,
            )

        if availability.groq:
            return IntentDecision(
                mode="groq",
                reason="Groq is available and the request looks more custom than the offline dataset.",
                intent=matched_keywords[0] if matched_keywords else "custom_laravel_task",
                confidence=max(match.score, 10),
                keywords=matched_keywords,
            )

        if availability.local:
            return IntentDecision(
                mode="local",
                reason="Only offline generation is available, so the assistant will use the local model.",
                intent=matched_keywords[0] if matched_keywords else "local_laravel_task",
                confidence=max(match.score, 10),
                keywords=matched_keywords,
            )

        return IntentDecision(
            mode="mini",
            reason="The offline Laravel dataset is the only available mode.",
            intent=matched_keywords[0] if matched_keywords else "laravel_task",
            confidence=max(match.score, 1),
            keywords=matched_keywords,
        )

