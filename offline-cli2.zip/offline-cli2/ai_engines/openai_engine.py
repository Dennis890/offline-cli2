from __future__ import annotations

import os

import requests

import config
from utils.errors import OpenAIModeError
from utils.models import EngineResult
from utils.response_parser import build_prompt, validate_and_normalize_response


class OpenAIEngine:
    mode_name = "openai"

    def is_available(self) -> bool:
        api_key = os.getenv("OPENAI_API_KEY", "").strip() or getattr(config, "OPENAI_API_KEY", "").strip()
        return bool(api_key and api_key != "PASTE_API_KEY_HERE")

    def run(self, task: str) -> EngineResult:
        api_key = os.getenv("OPENAI_API_KEY", "").strip() or getattr(config, "OPENAI_API_KEY", "").strip()
        if not api_key or api_key == "PASTE_API_KEY_HERE":
            raise OpenAIModeError("Missing OpenAI API key in config.py or OPENAI_API_KEY.")

        payload = {
            "model": config.OPENAI_MODEL,
            "input": [
                {
                    "role": "developer",
                    "content": [
                        {
                            "type": "input_text",
                            "text": (
                                "You are a professional Laravel (PHP) expert. "
                                "Answer only with Laravel and PHP solutions. "
                                "Do not include any other framework. "
                                "Keep it beginner friendly and practical."
                            ),
                        }
                    ],
                },
                {
                    "role": "user",
                    "content": [{"type": "input_text", "text": build_prompt(task)}],
                },
            ],
            "max_output_tokens": config.OPENAI_MAX_OUTPUT_TOKENS,
        }
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        try:
            response = requests.post(
                config.OPENAI_API_URL,
                json=payload,
                headers=headers,
                timeout=config.REQUEST_TIMEOUT_SECONDS,
            )
        except requests.RequestException as error:
            raise OpenAIModeError(f"OpenAI request failed: {error}") from error

        if response.status_code >= 400:
            try:
                error_payload = response.json()
            except ValueError:
                error_payload = {"error": {"message": response.text.strip() or "Unknown error"}}
            message = error_payload.get("error", {}).get("message") or response.text.strip()
            raise OpenAIModeError(message or f"HTTP {response.status_code}")

        try:
            payload = response.json()
        except ValueError as error:
            raise OpenAIModeError("OpenAI returned invalid JSON.") from error

        text = self.extract_text(payload)
        normalized = validate_and_normalize_response(text, "OpenAI")
        return EngineResult(mode=self.mode_name, text=normalized, matched=True, auto_learn=True)

    def extract_text(self, payload: dict) -> str:
        direct_text = payload.get("output_text")
        if isinstance(direct_text, str) and direct_text.strip():
            return direct_text

        parts: list[str] = []
        for item in payload.get("output", []):
            for content in item.get("content", []):
                text = content.get("text")
                if isinstance(text, str) and text.strip():
                    parts.append(text)
        return "\n".join(parts).strip()
