from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ResponseStep:
    file_path: str
    code: str
    explanation: str
    language: str = "text"


@dataclass
class EngineResult:
    mode: str
    text: str
    matched: bool = True
    cacheable: bool = True
    auto_learn: bool = False


@dataclass
class MatchResult:
    entry: dict | None
    score: int


@dataclass
class IntentDecision:
    mode: str
    reason: str
    intent: str
    confidence: int
    keywords: list[str] = field(default_factory=list)


@dataclass
class CommandRequest:
    command: str
    task: str = ""
    explicit_mode: str | None = None
    search_term: str = ""
    export_path: str = ""
    apply_files: bool = False
    no_color: bool = False
    offline: bool = False

