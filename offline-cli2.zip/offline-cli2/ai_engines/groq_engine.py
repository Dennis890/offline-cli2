from __future__ import annotations

import os

import requests

import config
from utils.errors import GroqModeError
from utils.models import EngineResult
from utils.response_parser import build_prompt, validate_and_normalize_response


class GroqEngine:
    mode_name = "groq"

    def is_available(self) -> bool:
        return bool(os.getenv("GROQ_API_KEY", "").strip() or getattr(config, "GROQ_API_KEY", "").strip())

    def run(self, task: str) -> EngineResult:
        api_key = os.getenv("GROQ_API_KEY", "").strip() or getattr(config, "GROQ_API_KEY", "").strip()
        if not api_key:
            raise GroqModeError("Missing Groq API key in config.py or GROQ_API_KEY.")

        payload = {
            "model": config.GROQ_MODEL,
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You are a professional Laravel (PHP) expert. "
                        "Answer only with Laravel and PHP solutions. "
                        "Do not include any other framework. "
                        "Keep it beginner friendly and practical."
                    ),
                },
                {"role": "user", "content": build_prompt(task)},
            ],
            "temperature": config.GROQ_TEMPERATURE,
        }
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        try:
            response = requests.post(
                config.GROQ_API_URL,
                json=payload,
                headers=headers,
                timeout=config.REQUEST_TIMEOUT_SECONDS,
            )
        except requests.RequestException as error:
            raise GroqModeError(f"Groq request failed: {error}") from error

        if response.status_code >= 400:
            try:
                error_payload = response.json()
            except ValueError:
                error_payload = {"error": {"message": response.text.strip() or "Unknown error"}}
            message = error_payload.get("error", {}).get("message") or response.text.strip()
            raise GroqModeError(message or f"HTTP {response.status_code}")

        try:
            payload = response.json()
        except ValueError as error:
            raise GroqModeError("Groq returned invalid JSON.") from error

        choices = payload.get("choices", [])
        if not choices:
            raise GroqModeError("Groq returned no choices.")

        message = choices[0].get("message", {})
        normalized = validate_and_normalize_response(message.get("content", ""), "Groq")
        return EngineResult(mode=self.mode_name, text=normalized, matched=True, auto_learn=True)
