import fs from 'fs/promises';
import { existsSync } from 'fs';
import { Mutex } from 'async-mutex';
import { config } from '../config/env';
import { logger } from '../utils/logger';
import { createBackup } from '../utils/backup';
import path from 'path';

export class FileRepository<T extends { id?: string }> {
  private filePath: string;
  private mutex: Mutex;
  private cache: T[] | null = null; // In-memory cache

  constructor(filePath: string) {
    this.filePath = filePath;
    this.mutex = new Mutex();
    this.init();
  }

  // Initialize file if it doesn't exist and load cache
  private async init() {
    await this.mutex.runExclusive(async () => {
      const dir = path.dirname(this.filePath);
      if (!existsSync(dir)) {
        await fs.mkdir(dir, { recursive: true });
      }
      
      if (!existsSync(this.filePath)) {
        await fs.writeFile(this.filePath, JSON.stringify([]), 'utf-8');
        this.cache = [];
        logger.info(`Created new data file at ${this.filePath}`);
      } else {
        await this.loadCache();
      }
    });
  }

  private async loadCache(): Promise<void> {
    try {
      const data = await fs.readFile(this.filePath, 'utf-8');
      this.cache = JSON.parse(data);
      logger.info('Data loaded into cache successfully.');
    } catch (error) {
      logger.error('Error reading or parsing data file. File might be corrupted.', error);
      throw new Error('Data file corrupted or unreadable');
    }
  }

  private async persistData(data: T[]): Promise<void> {
    if (config.enableBackups) {
      await createBackup(this.filePath, config.backupDirPath);
    }
    await fs.writeFile(this.filePath, JSON.stringify(data, null, 2), 'utf-8');
    this.cache = data;
  }

  public async findAll(): Promise<T[]> {
    if (!this.cache) {
      await this.mutex.runExclusive(async () => {
         await this.loadCache();
      });
    }
    return this.cache || [];
  }

  public async findById(id: string): Promise<T | undefined> {
    const data = await this.findAll();
    return data.find(item => item.id === id);
  }

  public async create(item: T): Promise<T> {
    return await this.mutex.runExclusive(async () => {
      const data = await this.findAll();
      data.push(item);
      await this.persistData(data);
      logger.info(`Created new item with id ${item.id}`);
      return item;
    });
  }

  public async update(id: string, updatedFields: Partial<T>): Promise<T | null> {
    return await this.mutex.runExclusive(async () => {
      const data = await this.findAll();
      const index = data.findIndex(item => item.id === id);
      
      if (index === -1) return null;

      const updatedItem = { ...data[index], ...updatedFields };
      data[index] = updatedItem;
      await this.persistData(data);
      logger.info(`Updated item with id ${id}`);
      return updatedItem;
    });
  }

  public async delete(id: string): Promise<boolean> {
    return await this.mutex.runExclusive(async () => {
      const data = await this.findAll();
      const initialLength = data.length;
      const filteredData = data.filter(item => item.id !== id);
      
      if (filteredData.length === initialLength) return false;

      await this.persistData(filteredData);
      logger.info(`Deleted item with id ${id}`);
      return true;
    });
  }
}
