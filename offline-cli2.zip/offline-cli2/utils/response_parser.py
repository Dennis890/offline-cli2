from __future__ import annotations

import json
import re
from typing import Iterable

from .constants import BLOCKED_FRAMEWORKS
from .errors import ValidationError
from .models import ResponseStep


STEP_BLOCK_PATTERN = re.compile(
    r"Step\s+(?P<number>\d+)\s*:\s*(?P<file>[^\n]+)\n(?P<body>.*?)(?=(?:\nStep\s+\d+\s*:)|\Z)",
    re.IGNORECASE | re.DOTALL,
)
EXPLANATION_PATTERN = re.compile(r"Explanation\s*:\s*(?P<text>.+)$", re.IGNORECASE | re.MULTILINE)


def normalize_request(text: str) -> str:
    return " ".join(text.strip().split())


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9_]+", text.lower())


def slugify(text: str) -> str:
    slug = "_".join(tokenize(text)[:8]).strip("_")
    return slug or "laravel_feature"


def contains_blocked_framework(text: str) -> str | None:
    lowered = text.lower()
    for item in sorted(BLOCKED_FRAMEWORKS):
        if "." in item:
            if item in lowered:
                return item
            continue

        if re.search(rf"\b{re.escape(item)}\b", lowered):
            return item
    return None


def build_prompt(user_request: str) -> str:
    from .constants import PROMPT_TEMPLATE

    return PROMPT_TEMPLATE.format(user_request=user_request)


def detect_language(file_path: str, fallback: str | None = None) -> str:
    if fallback:
        return fallback

    lowered = file_path.lower()
    if lowered.endswith(".blade.php"):
        return "blade"
    if lowered.endswith(".php"):
        return "php"
    if lowered.endswith(".json"):
        return "json"
    if lowered.endswith(".bat"):
        return "bat"
    if lowered.endswith(".md"):
        return "md"
    return "text"


def render_scope_only_response(framework_name: str) -> str:
    return "\n".join(
        [
            "Step 1: Laravel scope",
            "```text",
            f"This CLI only supports Laravel and PHP tasks. Remove '{framework_name}' from the request and ask for a Laravel feature instead.",
            "```",
            "Explanation: This keeps every answer focused on Laravel project code only.",
        ]
    )


def render_offline_help() -> str:
    return "\n".join(
        [
            "Step 1: dataset/mini_ai.json",
            "```text",
            "Offline mode supports Laravel topics such as login, register, Sanctum API auth, CRUD, validation, file upload, pagination, Blade UI, migrations, relationships, queues, events, notifications, caching, and more.",
            "```",
            "Explanation: Ask for a Laravel feature with simple words and the assistant will match the closest offline answer.",
        ]
    )


def looks_like_project_file(file_path: str) -> bool:
    lowered = file_path.strip().lower()
    if lowered in {"command prompt", "laravel scope"}:
        return False
    return "/" in lowered or "\\" in lowered or "." in lowered


def strip_to_steps(text: str) -> str:
    cleaned = text.strip()
    index = cleaned.find("Step 1:")
    if index >= 0:
        return cleaned[index:].strip()
    return cleaned


def _extract_code(body: str) -> tuple[str, str]:
    fence_match = re.search(r"```(?P<lang>[a-zA-Z0-9_-]*)\n(?P<code>.*?)```", body, re.DOTALL)
    if fence_match:
        return fence_match.group("lang").strip() or "text", fence_match.group("code").strip("\n")

    if "Explanation:" in body:
        code_text = body.split("Explanation:", 1)[0].strip()
        return "text", code_text

    return "text", body.strip()


def parse_structured_response(text: str) -> list[ResponseStep]:
    cleaned = strip_to_steps(text)
    steps: list[ResponseStep] = []

    for match in STEP_BLOCK_PATTERN.finditer(cleaned):
        file_path = match.group("file").strip()
        body = match.group("body").strip()
        explanation_match = EXPLANATION_PATTERN.search(body)
        if not explanation_match:
            continue

        explanation = explanation_match.group("text").strip()
        language, code = _extract_code(body)
        if not code:
            continue

        steps.append(
            ResponseStep(
                file_path=file_path,
                code=code,
                explanation=explanation,
                language=detect_language(file_path, language),
            )
        )

    return steps


def format_steps(steps: Iterable[ResponseStep]) -> str:
    lines: list[str] = []
    step_list = list(steps)

    for index, step in enumerate(step_list, start=1):
        lines.append(f"Step {index}: {step.file_path}")
        lines.append(f"```{detect_language(step.file_path, step.language)}")
        lines.extend(step.code.rstrip().splitlines())
        lines.append("```")
        lines.append("")
        lines.append(f"Explanation: {step.explanation.strip()}")
        if index != len(step_list):
            lines.append("")

    return "\n".join(lines).strip()


def validate_and_normalize_response(text: str, source_name: str) -> str:
    cleaned = strip_to_steps(text)
    if not cleaned:
        raise ValidationError(f"{source_name} returned an empty response.")

    blocked = contains_blocked_framework(cleaned)
    if blocked:
        raise ValidationError(
            f"{source_name} returned non-Laravel content mentioning '{blocked}'."
        )

    steps = parse_structured_response(cleaned)
    if not steps:
        raise ValidationError(
            f"{source_name} did not return the required Step / Explanation Laravel format."
        )

    return format_steps(steps)


def response_to_dataset_steps(text: str) -> list[dict]:
    return [
        {
            "file": step.file_path,
            "language": detect_language(step.file_path, step.language),
            "code_lines": step.code.splitlines(),
            "explanation": step.explanation,
        }
        for step in parse_structured_response(text)
    ]


def to_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=True, indent=2)
