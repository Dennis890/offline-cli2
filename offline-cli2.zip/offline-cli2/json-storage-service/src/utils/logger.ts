// A simple custom logger to track operations with timestamps
export const logger = {
  info: (message: string, meta?: any) => {
    console.log(`[${new Date().toISOString()}] [INFO] ${message}`, meta ? JSON.stringify(meta) : '');
  },
  error: (message: string, error?: any) => {
    console.error(`[${new Date().toISOString()}] [ERROR] ${message}`, error instanceof Error ? error.message : error || '');
  },
  warn: (message: string, meta?: any) => {
    console.warn(`[${new Date().toISOString()}] [WARN] ${message}`, meta ? JSON.stringify(meta) : '');
  }
};
