from __future__ import annotations

import subprocess
from pathlib import Path

import config
from utils.errors import LocalModeError
from utils.models import EngineResult
from utils.response_parser import build_prompt, validate_and_normalize_response


class LocalEngine:
    mode_name = "local"

    def __init__(self, base_dir: Path) -> None:
        self.base_dir = base_dir
        self.executable_path = base_dir / config.LOCAL_MODEL_PATH
        self.model_path = base_dir / config.LOCAL_MODEL_FILE

    def is_available(self) -> bool:
        return self.executable_path.exists() and self.model_path.exists()

    def run(self, task: str) -> EngineResult:
        if not self.executable_path.exists():
            raise LocalModeError(f"Missing local executable: '{self.executable_path}'.")
        if not self.model_path.exists():
            raise LocalModeError(f"Missing local model file: '{self.model_path}'.")

        prompt = build_prompt(task)
        errors: list[str] = []

        for command in self._commands(prompt):
            try:
                result = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    cwd=self.executable_path.parent,
                    timeout=config.LOCAL_TIMEOUT_SECONDS,
                    check=False,
                )
            except OSError as error:
                errors.append(f"{command[0]} could not start: {error}")
                continue
            except subprocess.TimeoutExpired:
                errors.append("Local model command timed out.")
                continue

            if result.returncode != 0:
                stderr_text = result.stderr.strip() or result.stdout.strip()
                errors.append(f"Command failed with exit code {result.returncode}: {stderr_text}")
                continue

            normalized = validate_and_normalize_response(result.stdout, "Local model")
            return EngineResult(mode=self.mode_name, text=normalized, matched=True)

        raise LocalModeError(errors[-1] if errors else "Local model did not return a usable response.")

    def _commands(self, prompt: str) -> list[list[str]]:
        exe = str(self.executable_path)
        model = str(self.model_path)
        token_count = str(config.LOCAL_MAX_OUTPUT_TOKENS)
        return [
            [exe, "-m", model, "-p", prompt, "-n", token_count],
            [exe, "--model", model, "--prompt", prompt],
            [exe, prompt],
        ]
