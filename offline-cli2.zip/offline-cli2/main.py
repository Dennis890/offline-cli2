import os
import sys
import json
import urllib.request
import urllib.error
import datetime
from pathlib import Path

BASE_DIR = Path(__file__).parent.resolve()
CONFIG_FILE = BASE_DIR / "config.json"
DATASET_PATH = BASE_DIR / "dataset" / "mini_ai.json"
FALLBACK_LOG = BASE_DIR / "logs" / "fallback.log"

SUPPORTED_MODELS = ["local", "openai", "groq", "llama", "claude"]

# Try to load API keys from config.py as a fallback for environment variables
try:
    import config as py_config
    CONFIG_OPENAI_KEY = getattr(py_config, "OPENAI_API_KEY", None)
    CONFIG_GROQ_KEY = getattr(py_config, "GROQ_API_KEY", None)
    CONFIG_CLAUDE_KEY = getattr(py_config, "ANTHROPIC_API_KEY", None)
    CONFIG_CLAUDE_MODEL = getattr(py_config, "ANTHROPIC_MODEL", "claude-3-haiku-20240307")
except ImportError:
    CONFIG_OPENAI_KEY = None
    CONFIG_GROQ_KEY = None
    CONFIG_CLAUDE_KEY = None
    CONFIG_CLAUDE_MODEL = "claude-3-haiku-20240307"

def log_fallback(failed_model, error_msg, query):
    log_dir = FALLBACK_LOG.parent
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] Fallback from {failed_model.upper()} to LOCAL.\nQuery: {query}\nError: {error_msg}\n{'-'*40}\n"
    with open(FALLBACK_LOG, "a", encoding="utf-8") as f:
        f.write(log_entry)

def load_config():
    if not CONFIG_FILE.exists():
        print("❌ Error: config.json missing. Please run 'ai setup' first.")
        sys.exit(1)
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_config(config):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4)

def install_model(model):
    if model not in SUPPORTED_MODELS:
        print(f"❌ Unknown model '{model}'. Supported: {', '.join(SUPPORTED_MODELS)}")
        return
    
    config = load_config()
    installed = config.get("installed_models", [])
    
    if model in installed:
        print(f"✅ Model '{model}' is already installed.")
        return

    print(f"⏳ Setting up '{model}' model...")
    
    if model == "openai":
        api_key = os.environ.get("OPENAI_API_KEY") or CONFIG_OPENAI_KEY
        if not api_key:
            print("❌ OPENAI_API_KEY environment variable is not set.")
            print("Please set it before installing OpenAI:")
            print("  CMD: set OPENAI_API_KEY=your_key")
            print("  PowerShell: $env:OPENAI_API_KEY=\"your_key\"")
            print("  (Or add OPENAI_API_KEY to config.py)")
            return
        print("✅ OpenAI API key validated.")

    elif model == "groq":
        api_key = os.environ.get("GROQ_API_KEY") or CONFIG_GROQ_KEY
        if not api_key:
            print("❌ GROQ_API_KEY environment variable is not set.")
            print("Please set it before installing Groq:")
            print("  CMD: set GROQ_API_KEY=your_key")
            print("  PowerShell: $env:GROQ_API_KEY=\"your_key\"")
            print("  (Or add GROQ_API_KEY to config.py)")
            return
        print("✅ Groq API key validated.")

    elif model == "claude":
        api_key = os.environ.get("ANTHROPIC_API_KEY") or CONFIG_CLAUDE_KEY
        if not api_key:
            print("❌ ANTHROPIC_API_KEY environment variable is not set.")
            print("Please set it before installing Claude:")
            print("  CMD: set ANTHROPIC_API_KEY=your_key")
            print("  PowerShell: $env:ANTHROPIC_API_KEY=\"your_key\"")
            print("  (Or add ANTHROPIC_API_KEY to config.py)")
            return
        print("✅ Claude API key validated.")

    elif model == "llama":
        model_files = list(BASE_DIR.glob("*.gguf")) + list(BASE_DIR.glob("*.bin"))
        if not model_files:
            print("❌ Local LLaMA model file (*.gguf or *.bin) not found in the current directory.")
            print("Please download a LLaMA model file and place it here before installing.")
            return
        print(f"✅ Found LLaMA model: {model_files[0].name}")

    elif model == "local":
        if not DATASET_PATH.exists():
            print(f"❌ Dataset not found at {DATASET_PATH}. Run 'ai setup' to create a dummy dataset.")
            return
        print("✅ Local dataset validated.")

    installed.append(model)
    config["installed_models"] = installed
    save_config(config)
    print(f"✅ Model '{model}' installed successfully.")

def use_model(model):
    if model not in SUPPORTED_MODELS:
        print(f"❌ Unknown model '{model}'. Supported: {', '.join(SUPPORTED_MODELS)}")
        return
        
    config = load_config()
    if model not in config.get("installed_models", []):
        print(f"❌ Model '{model}' is not installed. Run 'ai install {model}' first.")
        return
        
    config["current_model"] = model
    save_config(config)
    print(f"✅ Switched active model to: {model}")

def show_status():
    config = load_config()
    current = config.get("current_model", "None")
    installed = config.get("installed_models", [])
    
    print("📊 AI CLI System Status")
    print("=======================")
    print(f"Current Active Model: {current}")
    print("Installed Models:")
    if not installed:
        print("  - None")
    else:
        for m in installed:
            active_mark = " (Active)" if m == current else ""
            print(f"  - {m}{active_mark}")

def handle_local(query):
    if not DATASET_PATH.exists():
        print(f"❌ Dataset not found at {DATASET_PATH}")
        return False
        
    try:
        with open(DATASET_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
            entries = data.get("entries", [])
            for entry in entries:
                name_match = query.lower() in entry.get("name", "").lower()
                kw_match = any(query.lower() in kw.lower() for kw in entry.get("keywords", []))
                
                if name_match or kw_match:
                    print(f"\n💡 Topic: {entry['name']}")
                    for step in entry.get("steps", []):
                        print(f"📄 File: {step.get('file')}")
                        print(f"📝 Explanation: {step.get('explanation')}")
                        print("-" * 20)
                    return True
            
            print(f"❌ No matches found for '{query}' in the local dataset.")
            return True # Successfully searched, but no result
    except Exception as e:
        print(f"❌ Error reading dataset: {e}")
        return False

def handle_openai(query):
    api_key = os.environ.get("OPENAI_API_KEY") or CONFIG_OPENAI_KEY
    if not api_key:
        raise Exception("OPENAI_API_KEY is missing from environment variables and config.py.")
        
    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=json.dumps({
            "model": "gpt-3.5-turbo",
            "messages": [{"role": "system", "content": "You are a helpful developer assistant. Provide structured, readable answers without raw JSON dumps."}, {"role": "user", "content": query}]
        }).encode("utf-8"),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}
    )
    
    with urllib.request.urlopen(req) as response:
        res_data = json.loads(response.read().decode("utf-8"))
        answer = res_data["choices"][0]["message"]["content"]
        print("\n" + answer + "\n")

def handle_groq(query):
    api_key = os.environ.get("GROQ_API_KEY") or CONFIG_GROQ_KEY
    if not api_key:
        raise Exception("GROQ_API_KEY is missing from environment variables and config.py.")
        
    req = urllib.request.Request(
        "https://api.groq.com/openai/v1/chat/completions",
        data=json.dumps({
            "model": "llama-3.3-70b-versatile",
            "messages": [{"role": "system", "content": "You are a helpful developer assistant. Provide structured, readable answers without raw JSON dumps."}, {"role": "user", "content": query}]
        }).encode("utf-8"),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}
    )
    
    with urllib.request.urlopen(req) as response:
        res_data = json.loads(response.read().decode("utf-8"))
        answer = res_data["choices"][0]["message"]["content"]
        print("\n" + answer + "\n")

def handle_claude(query):
    api_key = os.environ.get("ANTHROPIC_API_KEY") or CONFIG_CLAUDE_KEY
    if not api_key:
        raise Exception("ANTHROPIC_API_KEY is missing from environment variables and config.py.")
        
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps({
            "model": CONFIG_CLAUDE_MODEL,
            "max_tokens": 1024,
            "system": "You are a helpful developer assistant. Provide structured, readable answers without raw JSON dumps.",
            "messages": [{"role": "user", "content": query}]
        }).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01"
        }
    )
    
    with urllib.request.urlopen(req) as response:
        res_data = json.loads(response.read().decode("utf-8"))
        answer = res_data["content"][0]["text"]
        print("\n" + answer + "\n")

def handle_llama(query):
    model_files = list(BASE_DIR.glob("*.gguf")) + list(BASE_DIR.glob("*.bin"))
    if not model_files:
        print("\n❌ Local LLaMA not installed or model file missing.")
        return False
        
    print(f"\n🦙 Found LLaMA model: {model_files[0].name}")
    print(f"Generating response locally for '{query}'...\n")
    print("This is a simulated LLaMA output. To use a real local LLaMA, you'd need llama-cpp-python or similar installed.")
    return True

def ask_query(query):
    config = load_config()
    model = config.get("current_model")
    
    if not model:
        print("❌ No model selected. Run 'ai use <model>' first.")
        return
        
    print(f"🔍 Searching... [{model.upper()}] Thinking...")
    
    if model == "local":
        handle_local(query)
    elif model == "llama":
        handle_llama(query)
    elif model == "openai":
        try:
            handle_openai(query)
            print("✅ Success")
        except Exception as e:
            error_msg = str(e)
            if isinstance(e, urllib.error.HTTPError):
                error_msg = e.read().decode("utf-8")
            print(f"❌ Error with OpenAI: {error_msg}")
            print(f"🔄 Falling back to LOCAL model...")
            log_fallback("openai", error_msg, query)
            handle_local(query)
            print("✅ Success (Fallback)")
    elif model == "groq":
        try:
            handle_groq(query)
            print("✅ Success")
        except Exception as e:
            error_msg = str(e)
            if isinstance(e, urllib.error.HTTPError):
                error_msg = e.read().decode("utf-8")
            print(f"❌ Error with Groq: {error_msg}")
            print(f"🔄 Falling back to LOCAL model...")
            log_fallback("groq", error_msg, query)
            handle_local(query)
            print("✅ Success (Fallback)")
    elif model == "claude":
        try:
            handle_claude(query)
            print("✅ Success")
        except Exception as e:
            error_msg = str(e)
            if isinstance(e, urllib.error.HTTPError):
                error_msg = e.read().decode("utf-8")
            print(f"❌ Error with Claude: {error_msg}")
            print(f"🔄 Falling back to LOCAL model...")
            log_fallback("claude", error_msg, query)
            handle_local(query)
            print("✅ Success (Fallback)")

def print_help():
    print("AI CLI System - Commands:")
    print("  ai setup             - Initialize configuration and folders")
    print("  ai install <model>   - Install a specific model (local, openai, groq, claude, llama)")
    print("  ai use <model>       - Set the active model")
    print("  ai ask \"<query>\"     - Ask the active model a question")
    print("  ai status            - Show current model and installed models")

def main():
    if len(sys.argv) < 2:
        print_help()
        return

    command = sys.argv[1].lower()
    args = " ".join(sys.argv[2:])

    if command == "setup":
        print("Please run 'ai setup' via the batch/ps1 script or run 'python setup.py'.")
        return

    if command == "install":
        if not args:
            print("❌ Missing model name.")
            return
        install_model(args.strip())
    elif command == "use":
        if not args:
            print("❌ Missing model name.")
            return
        use_model(args.strip())
    elif command == "ask":
        if not args:
            print("❌ Missing query.")
            return
        ask_query(args.strip())
    elif command == "status":
        show_status()
    else:
        print(f"❌ Unknown command: {command}")
        print_help()

if __name__ == "__main__":
    main()
