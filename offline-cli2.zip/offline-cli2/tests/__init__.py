"""Smoke tests for the Laravel CLI assistant."""
