from __future__ import annotations

import os

import requests

import config
from utils.errors import ClaudeModeError
from utils.models import EngineResult
from utils.response_parser import build_prompt, validate_and_normalize_response


class ClaudeEngine:
    mode_name = "claude"

    def is_available(self) -> bool:
        return bool(os.getenv("ANTHROPIC_API_KEY", "").strip() or getattr(config, "ANTHROPIC_API_KEY", "").strip())

    def run(self, task: str) -> EngineResult:
        api_key = os.getenv("ANTHROPIC_API_KEY", "").strip() or getattr(config, "ANTHROPIC_API_KEY", "").strip()
        if not api_key:
            raise ClaudeModeError("Missing Anthropic API key in config.py or ANTHROPIC_API_KEY.")

        payload = {
            "model": config.ANTHROPIC_MODEL,
            "max_tokens": config.ANTHROPIC_MAX_OUTPUT_TOKENS,
            "system": (
                "You are a professional Laravel (PHP) expert. "
                "Answer only with Laravel and PHP solutions. "
                "Do not include any other framework. "
                "Keep it beginner friendly and practical."
            ),
            "messages": [{"role": "user", "content": build_prompt(task)}],
        }
        headers = {
            "x-api-key": api_key,
            "anthropic-version": config.ANTHROPIC_API_VERSION,
            "content-type": "application/json",
        }

        try:
            response = requests.post(
                config.ANTHROPIC_API_URL,
                json=payload,
                headers=headers,
                timeout=config.REQUEST_TIMEOUT_SECONDS,
            )
        except requests.RequestException as error:
            raise ClaudeModeError(f"Claude request failed: {error}") from error

        if response.status_code >= 400:
            try:
                error_payload = response.json()
            except ValueError:
                error_payload = {"error": {"message": response.text.strip() or "Unknown error"}}
            message = error_payload.get("error", {}).get("message") or response.text.strip()
            raise ClaudeModeError(message or f"HTTP {response.status_code}")

        try:
            payload = response.json()
        except ValueError as error:
            raise ClaudeModeError("Claude returned invalid JSON.") from error

        content = payload.get("content", [])
        text_parts = [item.get("text", "") for item in content if item.get("type") == "text"]
        normalized = validate_and_normalize_response("\n".join(text_parts).strip(), "Claude")
        return EngineResult(mode=self.mode_name, text=normalized, matched=True, auto_learn=True)
