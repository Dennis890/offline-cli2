@echo off
set "SCRIPT_DIR=%~dp0"

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [X] Error: Python is not installed or not found in PATH!
    echo.
    echo Please install Python (from python.org or Windows Store^).
    echo If you are on a locked college PC, download the "Windows embeddable package"
    echo from python.org, extract it to this folder, and rename python.exe if needed.
    echo.
    exit /b 1
)

if /I "%1"=="setup" (
    python "%SCRIPT_DIR%setup.py"
) else (
    python "%SCRIPT_DIR%main.py" %*
)
