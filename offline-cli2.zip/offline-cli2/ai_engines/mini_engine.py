from __future__ import annotations

from dataset.store import DatasetStore
from utils.models import EngineResult, ResponseStep
from utils.response_parser import format_steps, render_offline_help


class MiniEngine:
    mode_name = "mini"

    def __init__(self, dataset_store: DatasetStore) -> None:
        self.dataset_store = dataset_store

    def run(self, task: str) -> EngineResult:
        match = self.dataset_store.best_match(task)
        if not match.entry:
            return EngineResult(mode=self.mode_name, text=render_offline_help(), matched=False)

        steps = []
        for item in match.entry.get("steps", []):
            code_lines = item.get("code_lines", [])
            steps.append(
                ResponseStep(
                    file_path=item["file"],
                    code="\n".join(code_lines) if code_lines else item.get("code", ""),
                    explanation=item["explanation"],
                    language=item.get("language", "text"),
                )
            )

        return EngineResult(mode=self.mode_name, text=format_steps(steps), matched=True)
