Place your local Laravel-focused files in this folder as:

local\main.exe
local\model.gguf

Expected behavior:
1. Accept either `main.exe -m model.gguf -p "prompt"` or one prompt argument from `main.py`
2. Return Laravel-only step-by-step output
3. Print file paths, code, and one-line explanations
4. Exit with code 0 on success

You can use a llama.cpp wrapper or any other local executable that follows this contract.
