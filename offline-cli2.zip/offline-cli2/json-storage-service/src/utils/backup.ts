import fs from 'fs/promises';
import path from 'path';
import { logger } from './logger';

export const createBackup = async (sourcePath: string, backupDirPath: string): Promise<void> => {
  try {
    await fs.mkdir(backupDirPath, { recursive: true });
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = path.basename(sourcePath);
    const backupPath = path.join(backupDirPath, `${filename}.${timestamp}.bak`);
    
    await fs.copyFile(sourcePath, backupPath);
    logger.info(`Backup created successfully: ${backupPath}`);
    
    // Optional: Clean up old backups here (e.g., keep last 10)
  } catch (error) {
    logger.error(`Failed to create backup of ${sourcePath}`, error);
    throw error;
  }
};
