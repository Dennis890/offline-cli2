import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { config } from './config/env';
import { logger } from './utils/logger';
import { StorageController } from './controllers/storage.controller';
import { validateRequest } from './middlewares/validateRequest';
import { ItemSchema, UpdateItemSchema } from './models/item.schema';
import { errorHandler } from './middlewares/errorHandler';

const app = express();

// Security middlewares
app.use(helmet());
app.use(cors());

// Rate limiting to prevent abuse
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// Body parsing with size limits for security
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// Logging middleware
app.use((req, res, next) => {
  logger.info(`Incoming Request: ${req.method} ${req.url}`);
  next();
});

// API Routes
const apiRouter = express.Router();

apiRouter.get('/items', StorageController.getAll);
apiRouter.get('/items/:id', StorageController.getById);
apiRouter.post('/items', validateRequest(ItemSchema), StorageController.create);
apiRouter.put('/items/:id', validateRequest(UpdateItemSchema), StorageController.update);
apiRouter.delete('/items/:id', StorageController.remove);

app.use('/api/v1', apiRouter);

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Global Error Handler
app.use(errorHandler);

app.listen(config.port, () => {
  logger.info(`Server is running on http://localhost:${config.port}`);
  logger.info(`Environment: ${config.nodeEnv}`);
  logger.info(`Data File Path: ${config.dataFilePath}`);
});
