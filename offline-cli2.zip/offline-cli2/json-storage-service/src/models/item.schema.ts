import { z } from 'zod';

// Define the schema for the data we want to store
// For this example, let's assume we are storing "Products" in a storage facility
export const ItemSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(2, "Name must be at least 2 characters long"),
  category: z.string().min(1, "Category is required"),
  quantity: z.number().int().nonnegative("Quantity must be a non-negative integer"),
  price: z.number().positive("Price must be a positive number"),
  location: z.object({
    aisle: z.string(),
    shelf: z.string()
  }).optional(),
  lastUpdated: z.string().datetime().optional()
});

export type Item = z.infer<typeof ItemSchema>;

export const UpdateItemSchema = ItemSchema.partial().omit({ id: true });
