# Laravel Hybrid AI CLI

Laravel Hybrid AI CLI is a Windows CMD-friendly assistant built only for PHP Laravel developers. It now supports smart intent detection, automatic engine selection, offline dataset learning, colorful output, dataset search, export, fallback logging, and optional file application.

## Project Structure

- `main.py` - CLI entry point
- `assistant.py` - command orchestration and fallback flow
- `config.py` - models, timeouts, paths, and feature flags
- `ai_engines/` - `mini`, `openai`, `claude`, `groq`, and `local` engines
- `utils/` - parsing, console colors, runtime state, intent detection, and file actions
- `dataset/mini_ai.json` - offline Laravel knowledge base
- `dataset/build_mini_ai_dataset.py` - offline dataset rebuild script
- `tests/smoke_test.py` - basic validation script
- `ai.bat` - Windows shortcut wrapper

## Install

1. Open Windows Command Prompt.
2. Move into the project folder.
3. Install dependencies:

```bat
python -m pip install -r requirements.txt
```

4. Set cloud API keys with environment variables if needed:

```bat
set OPENAI_API_KEY=your_openai_key
set ANTHROPIC_API_KEY=your_anthropic_key
set GROQ_API_KEY=your_groq_key
```

5. Put local model files here for offline generation:

```text
local\main.exe
local\model.gguf
```

## Main Commands

```bat
ai create login system
ai create api with sanctum
ai create middleware auth --offline
ai search login
ai export last-answer.txt
```

Backward-compatible explicit mode commands still work:

```bat
python main.py mini create login system
python main.py openai create api with sanctum
python main.py local create middleware auth
```

## Smart Mode Selection

- Simple Laravel tasks with strong dataset matches go to `mini`
- Complex Laravel logic prefers `openai`, then `claude`, then `groq`
- Offline requests prefer `local`
- Fallback chain:
  `openai -> claude -> groq -> local -> mini`

## Features

- Laravel-only enforcement
- Step-by-step output validation
- Colorful CMD output with `colorama`
- Search suggestions for unknown commands
- Search command for dataset discovery
- Export last answer to a file
- Cache, history, and fallback logs
- Auto-learning from good cloud responses into `dataset/mini_ai.json`
- Optional prompt-driven file creation with `--apply-files`

## Rebuild the Offline Dataset

```bat
python dataset\build_mini_ai_dataset.py
```

## Run Tests

```bat
python -m unittest tests.smoke_test
```

## Security Notes

- `config.py` uses placeholders by default.
- Prefer environment variables for real API keys.
- Fallback logs redact common secret-looking values before writing.
