import * as dotenv from 'dotenv';
import path from 'path';

dotenv.config();

export const config = {
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  dataFilePath: path.resolve(process.cwd(), process.env.DATA_FILE_PATH || './data/db.json'),
  backupDirPath: path.resolve(process.cwd(), process.env.BACKUP_DIR_PATH || './data/backups'),
  enableBackups: process.env.ENABLE_BACKUPS === 'true'
};
