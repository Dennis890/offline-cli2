from __future__ import annotations

from colorama import Fore, Style, init


class ConsolePrinter:
    def __init__(self, use_color: bool = True) -> None:
        self.use_color = use_color
        init(autoreset=True)

    def _paint(self, text: str, color: str) -> str:
        if not self.use_color:
            return text
        return f"{color}{text}{Style.RESET_ALL}"

    def info(self, message: str) -> None:
        print(self._paint(message, Fore.BLUE))

    def warn(self, message: str) -> None:
        print(self._paint(message, Fore.MAGENTA))

    def error(self, message: str) -> None:
        print(self._paint(message, Fore.RED))

    def success(self, message: str) -> None:
        print(self._paint(message, Fore.GREEN))

    def print_response(self, text: str) -> None:
        in_code = False
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("```"):
                in_code = not in_code
                print(self._paint(line, Fore.YELLOW))
                continue

            if in_code:
                print(self._paint(line, Fore.YELLOW))
            elif line.startswith("Step "):
                print(self._paint(line, Fore.CYAN))
            elif line.startswith("Explanation:"):
                print(self._paint(line, Fore.GREEN))
            else:
                print(line)

    def print_suggestions(self, suggestions: list[str]) -> None:
        if not suggestions:
            return
        print("Did you mean:")
        for suggestion in suggestions:
            print(self._paint(f"  - {suggestion}", Fore.CYAN))

    def print_search_results(self, term: str, results: list[dict]) -> None:
        if not results:
            self.warn(f"No Laravel dataset features matched '{term}'.")
            return

        self.info(f"Laravel dataset matches for '{term}':")
        for entry in results:
            keywords = ", ".join(entry.get("keywords", [])[:6])
            print(self._paint(f"- {entry.get('name', 'unknown')}", Fore.CYAN))
            print(self._paint(f"  Keywords: {keywords}", Fore.GREEN))

