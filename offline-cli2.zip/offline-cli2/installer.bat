@echo off
setlocal enabledelayedexpansion

title Laravel Hybrid AI CLI Installer

set "SCRIPT_DIR=%~dp0"
set "PROJECT_NAME=laravel_hybrid_ai_cli"
set "TARGET_DIR=%CD%\%PROJECT_NAME%"
set "PYTHON_CMD="
set "CORE_PACKAGE_URL="
set "LOCAL_MODEL_URL="

echo ==========================================
echo Laravel Hybrid AI CLI Installer
echo ==========================================
echo.

if not exist "%TARGET_DIR%" (
    mkdir "%TARGET_DIR%"
)

if not exist "%TARGET_DIR%\local" (
    mkdir "%TARGET_DIR%\local"
)

if not exist "%TARGET_DIR%\ai_engines" (
    mkdir "%TARGET_DIR%\ai_engines"
)

if not exist "%TARGET_DIR%\utils" (
    mkdir "%TARGET_DIR%\utils"
)

if not exist "%TARGET_DIR%\dataset" (
    mkdir "%TARGET_DIR%\dataset"
)

if not exist "%TARGET_DIR%\tests" (
    mkdir "%TARGET_DIR%\tests"
)

if not "%CORE_PACKAGE_URL%"=="" (
    echo Downloading core files...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%CORE_PACKAGE_URL%' -OutFile '%TARGET_DIR%\project.zip'"
    if errorlevel 1 (
        echo Failed to download the core package.
        exit /b 1
    )

    echo Extracting core files...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%TARGET_DIR%\project.zip' -DestinationPath '%TARGET_DIR%' -Force"
    if errorlevel 1 (
        echo Failed to extract the core package.
        exit /b 1
    )
) else (
    echo Copying bundled core files...
    copy /Y "%SCRIPT_DIR%main.py" "%TARGET_DIR%\" >nul
    copy /Y "%SCRIPT_DIR%assistant.py" "%TARGET_DIR%\" >nul
    copy /Y "%SCRIPT_DIR%config.py" "%TARGET_DIR%\" >nul
    copy /Y "%SCRIPT_DIR%requirements.txt" "%TARGET_DIR%\" >nul
    if exist "%SCRIPT_DIR%ai.bat" copy /Y "%SCRIPT_DIR%ai.bat" "%TARGET_DIR%\" >nul
    if exist "%SCRIPT_DIR%README.md" copy /Y "%SCRIPT_DIR%README.md" "%TARGET_DIR%\" >nul
    xcopy /E /I /Y "%SCRIPT_DIR%ai_engines" "%TARGET_DIR%\ai_engines" >nul
    xcopy /E /I /Y "%SCRIPT_DIR%utils" "%TARGET_DIR%\utils" >nul
    xcopy /E /I /Y "%SCRIPT_DIR%dataset" "%TARGET_DIR%\dataset" >nul
    xcopy /E /I /Y "%SCRIPT_DIR%tests" "%TARGET_DIR%\tests" >nul
    if exist "%SCRIPT_DIR%local\README.txt" copy /Y "%SCRIPT_DIR%local\README.txt" "%TARGET_DIR%\local\" >nul
)

where python >nul 2>nul
if not errorlevel 1 (
    set "PYTHON_CMD=python"
)

if "%PYTHON_CMD%"=="" (
    where py >nul 2>nul
    if not errorlevel 1 (
        set "PYTHON_CMD=py -3"
    )
)

if "%PYTHON_CMD%"=="" (
    echo Python was not found in PATH.
    echo Install Python 3.10 or later, then run this installer again.
    exit /b 1
)

echo.
echo Installing Python dependencies...
%PYTHON_CMD% -m pip install -r "%TARGET_DIR%\requirements.txt"
if errorlevel 1 (
    echo Failed to install Python dependencies.
    exit /b 1
)

echo.
set /p WANT_MODEL=Do you want to download the local model package now? (y/n): 
if /I "%WANT_MODEL%"=="Y" (
    if "%LOCAL_MODEL_URL%"=="" (
        echo LOCAL_MODEL_URL is empty inside installer.bat.
        echo Place your local executable and model at:
        echo %TARGET_DIR%\local\main.exe
        echo %TARGET_DIR%\local\model.gguf
    ) else (
        echo Downloading local model package...
        powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%LOCAL_MODEL_URL%' -OutFile '%TARGET_DIR%\local\model.zip'"
        if errorlevel 1 (
            echo Failed to download the local model package.
            exit /b 1
        )

        echo Extracting local model package...
        powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%TARGET_DIR%\local\model.zip' -DestinationPath '%TARGET_DIR%\local' -Force"
        if errorlevel 1 (
            echo Failed to extract the local model package.
            exit /b 1
        )
    )
)

echo.
echo Setup complete.
echo.
echo Next steps:
echo 1. Set OPENAI_API_KEY, ANTHROPIC_API_KEY, or GROQ_API_KEY if you want cloud AI mode.
echo 2. Put your local files at "%TARGET_DIR%\local\main.exe" and "%TARGET_DIR%\local\model.gguf" if you want local mode.
echo 3. Run these commands:
echo    cd /d "%TARGET_DIR%"
echo    %PYTHON_CMD% main.py create login system
echo    %PYTHON_CMD% main.py search sanctum
echo    %PYTHON_CMD% main.py export last-answer.txt
echo    ai create middleware auth
echo.
pause
