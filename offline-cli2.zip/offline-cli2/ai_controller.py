import sys
import json
import os
from pathlib import Path

# Paths
DATASET_PATH = Path("dataset/mini_ai.json")
STATE_FILE = Path("ai_state.json")

def load_state():
    """Load the CLI state from a JSON file to persist installed and active models."""
    if STATE_FILE.exists():
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"installed_models": [], "current_model": None}

def save_state(state):
    """Save the CLI state to a JSON file."""
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=4)

def install_model(model):
    state = load_state()
    supported_models = ["openai", "local", "llama"]
    
    if model not in supported_models:
        print(f"❌ Unknown model '{model}'. Supported models: openai, local, llama")
        return
        
    if model not in state["installed_models"]:
        print(f"⏳ Simulating download and setup for {model}...")
        state["installed_models"].append(model)
        save_state(state)
        
    print(f"✅ {model} installed successfully")

def use_model(model):
    state = load_state()
    if model not in state["installed_models"]:
        print(f"❌ Model not installed. Run ai install {model} first")
        return
        
    state["current_model"] = model
    save_state(state)
    print(f"✅ Switched to {model}")

def ask_query(query):
    state = load_state()
    model = state["current_model"]
    
    if not model:
        print("❌ No model selected. Run 'ai use <model>' first.")
        return
        
    if model == "openai":
        print(f"[OpenAI Response]: Simulating cloud API response for your query: '{query}'.")
        print("The request was processed successfully by the OpenAI engine.")
        
    elif model == "llama":
        print(f"[LLaMA Response]: Simulating local LLM inference for '{query}'.")
        print("Generated locally using simulated LLaMA weights.")
        
    elif model == "local":
        print(f"🔍 [Local]: Searching mini_ai.json dataset for '{query}'...")
        if DATASET_PATH.exists():
            try:
                with open(DATASET_PATH, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    entries = data.get("entries", [])
                    found = False
                    
                    for entry in entries:
                        name_match = query.lower() in entry.get("name", "").lower()
                        kw_match = any(query.lower() in kw.lower() for kw in entry.get("keywords", []))
                        
                        if name_match or kw_match:
                            print(f"\n✅ Found matching topic: {entry['name']}")
                            for step in entry.get("steps", []):
                                print(f"  -> File: {step.get('file')}")
                                print(f"     Explanation: {step.get('explanation')}")
                            found = True
                            break
                            
                    if not found:
                        print(f"❌ No matches found in the local dataset for '{query}'.")
            except Exception as e:
                print(f"❌ Error reading dataset: {e}")
        else:
            print(f"❌ Dataset not found at {DATASET_PATH}")

def main():
    if len(sys.argv) < 3:
        print("Usage:")
        print("  python ai_controller.py install <model>")
        print("  python ai_controller.py use <model>")
        print("  python ai_controller.py ask <query>")
        return

    command = sys.argv[1].lower()
    arg = " ".join(sys.argv[2:])

    if command == "install":
        install_model(arg)
    elif command == "use":
        use_model(arg)
    elif command == "ask":
        ask_query(arg)
    else:
        print(f"❌ Unknown command: {command}")

if __name__ == "__main__":
    main()
