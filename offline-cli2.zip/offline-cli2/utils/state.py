from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def sanitize_secret(text: str) -> str:
    redacted = re.sub(r"sk-[A-Za-z0-9_-]{10,}", "sk-REDACTED", text)
    redacted = re.sub(r"Bearer\s+[A-Za-z0-9._-]+", "Bearer REDACTED", redacted, flags=re.IGNORECASE)
    return redacted


class RuntimeState:
    def __init__(
        self,
        base_dir: Path,
        cache_dir: str,
        history_file: str,
        fallback_log_file: str,
        last_output_file: str,
        cache_enabled: bool,
    ) -> None:
        self.base_dir = base_dir
        self.cache_enabled = cache_enabled
        self.cache_dir = base_dir / cache_dir
        self.history_file = base_dir / history_file
        self.fallback_log_file = base_dir / fallback_log_file
        self.last_output_file = base_dir / last_output_file

        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.history_file.parent.mkdir(parents=True, exist_ok=True)
        self.fallback_log_file.parent.mkdir(parents=True, exist_ok=True)
        self.last_output_file.parent.mkdir(parents=True, exist_ok=True)

    def _key(self, bucket: str, request: str, salt: str = "") -> str:
        joined = "|".join([bucket, request, salt])
        return hashlib.sha256(joined.encode("utf-8")).hexdigest()

    def load_cache(self, bucket: str, request: str, salt: str = "") -> str | None:
        if not self.cache_enabled:
            return None

        path = self.cache_dir / f"{self._key(bucket, request, salt)}.json"
        if not path.exists():
            return None

        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

        response = payload.get("response")
        if isinstance(response, str) and response.strip():
            return response
        return None

    def save_cache(self, bucket: str, request: str, response: str, salt: str = "") -> None:
        if not self.cache_enabled:
            return

        path = self.cache_dir / f"{self._key(bucket, request, salt)}.json"
        payload = {
            "bucket": bucket,
            "request": request,
            "response": response,
            "saved_at": utc_now_iso(),
        }
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def log_history(
        self,
        requested_mode: str,
        resolved_mode: str,
        request: str,
        from_cache: bool = False,
        auto_mode: bool = False,
    ) -> None:
        payload = {
            "time": utc_now_iso(),
            "requested_mode": requested_mode,
            "resolved_mode": resolved_mode,
            "from_cache": from_cache,
            "auto_mode": auto_mode,
            "request": request,
        }
        with self.history_file.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=True) + "\n")

    def log_fallback(self, current_mode: str, next_mode: str, reason: str) -> None:
        message = f"[{current_mode} failed -> switching to {next_mode}]"
        sanitized_reason = sanitize_secret(reason)
        with self.fallback_log_file.open("a", encoding="utf-8") as handle:
            handle.write(f"{utc_now_iso()} | {message} | {sanitized_reason}\n")

    def save_last_output(self, task: str, mode: str, response: str) -> None:
        payload = {
            "time": utc_now_iso(),
            "task": task,
            "mode": mode,
            "response": response,
        }
        temp_path = self.last_output_file.with_suffix(".tmp")
        temp_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        temp_path.replace(self.last_output_file)

    def export_last_output(self, export_path: Path) -> Path:
        if not self.last_output_file.exists():
            raise FileNotFoundError("No previous output is available to export.")

        try:
            payload = json.loads(self.last_output_file.read_text(encoding="utf-8"))
        except ValueError as error:
            raise FileNotFoundError(
                "The last output file is empty or invalid. Run a Laravel generation command again."
            ) from error
        response = payload.get("response", "")
        export_path.parent.mkdir(parents=True, exist_ok=True)
        export_path.write_text(response, encoding="utf-8")
        return export_path
