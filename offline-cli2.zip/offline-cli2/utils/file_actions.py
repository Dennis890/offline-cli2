from __future__ import annotations

from pathlib import Path

from .response_parser import looks_like_project_file, parse_structured_response


class FileActionManager:
    def __init__(self, working_dir: Path) -> None:
        self.working_dir = working_dir

    def prompt_and_apply(self, response_text: str) -> list[Path]:
        steps = [step for step in parse_structured_response(response_text) if looks_like_project_file(step.file_path)]
        if not steps:
            return []

        answer = input("Do you want to create or update the files from this answer? (y/n): ").strip().lower()
        if answer not in {"y", "yes"}:
            return []

        written_paths: list[Path] = []
        for step in steps:
            target_path = self.working_dir / Path(step.file_path)
            target_path.parent.mkdir(parents=True, exist_ok=True)
            target_path.write_text(step.code.rstrip() + "\n", encoding="utf-8")
            written_paths.append(target_path)

        return written_paths
