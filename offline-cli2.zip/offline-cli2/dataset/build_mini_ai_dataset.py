from __future__ import annotations

import json
from pathlib import Path
from textwrap import dedent


DATASET_DIR = Path(__file__).resolve().parent


def step(file_path: str, language: str, code: str, explanation: str) -> dict:
    return {
        "file": file_path,
        "language": language,
        "code_lines": dedent(code).strip("\n").splitlines(),
        "explanation": explanation,
    }


entries = [
    {
        "name": "authentication_login_register",
        "keywords": ["login", "register", "auth", "authentication", "login system"],
        "steps": [
            step(
                "routes/web.php",
                "php",
                r"""
<?php

use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.store');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.store');
});

Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');
""",
                "These routes connect login, register, and logout to the Laravel auth controller.",
            ),
            step(
                "app/Http/Controllers/AuthController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AuthController extends Controller
{
    public function showLogin(): View
    {
        return view('auth.login');
    }

    public function login(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        if (! Auth::attempt($credentials)) {
            return back()->withErrors(['email' => 'Invalid credentials.'])->onlyInput('email');
        }

        $request->session()->regenerate();

        return redirect()->intended('/dashboard');
    }

    public function showRegister(): View
    {
        return view('auth.register');
    }

    public function register(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'unique:users,email'],
            'password' => ['required', 'confirmed', 'min:8'],
        ]);

        $user = User::create($validated);
        Auth::login($user);

        return redirect('/dashboard');
    }

    public function logout(Request $request): RedirectResponse
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/login');
    }
}
""",
                "This controller validates the form, creates the user, logs the user in, and logs the user out safely.",
            ),
            step(
                "app/Models/User.php",
                "php",
                r"""
<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    protected $fillable = ['name', 'email', 'password'];

    protected function casts(): array
    {
        return [
            'password' => 'hashed',
        ];
    }
}
""",
                "The model allows mass assignment and automatically hashes the password field.",
            ),
        ],
    },
    {
        "name": "password_reset",
        "keywords": ["password reset", "forgot password", "reset password"],
        "steps": [
            step(
                "routes/web.php",
                "php",
                r"""
<?php

use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use Illuminate\Support\Facades\Route;

Route::middleware('guest')->group(function () {
    Route::get('/forgot-password', [PasswordResetLinkController::class, 'create'])->name('password.request');
    Route::post('/forgot-password', [PasswordResetLinkController::class, 'store'])->name('password.email');
    Route::get('/reset-password/{token}', [NewPasswordController::class, 'create'])->name('password.reset');
    Route::post('/reset-password', [NewPasswordController::class, 'store'])->name('password.store');
});
""",
                "These routes give Laravel a complete password reset flow for guest users.",
            ),
            step(
                "app/Http/Controllers/Auth/PasswordResetLinkController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Illuminate\View\View;

class PasswordResetLinkController extends Controller
{
    public function create(): View
    {
        return view('auth.forgot-password');
    }

    public function store(Request $request): RedirectResponse
    {
        $request->validate(['email' => ['required', 'email']]);

        Password::sendResetLink($request->only('email'));

        return back()->with('status', 'Password reset link sent.');
    }
}
""",
                "This controller validates the email and asks Laravel to send the reset link.",
            ),
        ],
    },
    {
        "name": "email_verification",
        "keywords": ["email verification", "verify email", "verified user"],
        "steps": [
            step(
                "app/Models/User.php",
                "php",
                r"""
<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable implements MustVerifyEmail
{
    protected $fillable = ['name', 'email', 'password'];
}
""",
                "Implementing MustVerifyEmail tells Laravel this user must verify the email address.",
            ),
            step(
                "routes/web.php",
                "php",
                r"""
<?php

use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/email/verify', fn () => view('auth.verify-email'))->middleware('auth')->name('verification.notice');

Route::get('/email/verify/{id}/{hash}', function (EmailVerificationRequest $request) {
    $request->fulfill();

    return redirect('/dashboard');
})->middleware(['auth', 'signed'])->name('verification.verify');

Route::post('/email/verification-notification', function (Request $request) {
    $request->user()->sendEmailVerificationNotification();

    return back()->with('status', 'Verification link sent.');
})->middleware(['auth', 'throttle:6,1'])->name('verification.send');
""",
                "These routes show the verify page, confirm the signed link, and resend the email when needed.",
            ),
        ],
    },
    {
        "name": "auth_middleware",
        "keywords": ["auth middleware", "protect routes", "middleware auth"],
        "steps": [
            step(
                "routes/web.php",
                "php",
                r"""
<?php

use Illuminate\Support\Facades\Route;

Route::middleware('auth')->group(function () {
    Route::view('/dashboard', 'dashboard')->name('dashboard');
    Route::view('/profile', 'profile')->name('profile');
});
""",
                "The auth middleware makes sure only logged-in users can open these pages.",
            ),
            step(
                "resources/views/dashboard.blade.php",
                "blade",
                r"""
<h1>Dashboard</h1>
<p>Welcome, {{ auth()->user()->name }}.</p>
""",
                "This Blade file shows a simple protected page for authenticated users.",
            ),
        ],
    },
    {
        "name": "admin_middleware",
        "keywords": ["admin middleware", "admin access", "middleware admin"],
        "steps": [
            step(
                "app/Http/Middleware/EnsureUserIsAdmin.php",
                "php",
                r"""
<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserIsAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        abort_unless($request->user()?->is_admin, 403);

        return $next($request);
    }
}
""",
                "This middleware stops normal users before they reach admin pages.",
            ),
            step(
                "routes/web.php",
                "php",
                r"""
<?php

use App\Http\Middleware\EnsureUserIsAdmin;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth', EnsureUserIsAdmin::class])->group(function () {
    Route::view('/admin/dashboard', 'admin.dashboard')->name('admin.dashboard');
});
""",
                "These routes use both auth and admin middleware for safer access control.",
            ),
        ],
    },
    {
        "name": "crud_products_web",
        "keywords": ["crud", "crud full", "product crud", "resource controller"],
        "steps": [
            step(
                "database/migrations/2026_01_01_000001_create_products_table.php",
                "php",
                r"""
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->decimal('price', 10, 2);
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
""",
                "This migration creates a practical products table for CRUD work.",
            ),
            step(
                "app/Http/Controllers/ProductController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ProductController extends Controller
{
    public function index(): View
    {
        return view('products.index', ['products' => Product::latest()->get()]);
    }

    public function store(Request $request): RedirectResponse
    {
        Product::create($request->validate([
            'name' => ['required', 'string', 'max:255'],
            'price' => ['required', 'numeric'],
            'description' => ['nullable', 'string'],
        ]));

        return back()->with('success', 'Product created successfully.');
    }

    public function update(Request $request, Product $product): RedirectResponse
    {
        $product->update($request->validate([
            'name' => ['required', 'string', 'max:255'],
            'price' => ['required', 'numeric'],
            'description' => ['nullable', 'string'],
        ]));

        return redirect()->route('products.index')->with('success', 'Product updated successfully.');
    }

    public function destroy(Product $product): RedirectResponse
    {
        $product->delete();

        return back()->with('success', 'Product deleted successfully.');
    }
}
""",
                "The controller gives you real create, read, update, and delete logic for products.",
            ),
            step(
                "routes/web.php",
                "php",
                r"""
<?php

use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;

Route::resource('products', ProductController::class)->except(['create', 'show', 'edit']);
""",
                "A resource route quickly connects the standard product URLs to the controller.",
            ),
        ],
    },
    {
        "name": "crud_tasks_api",
        "keywords": ["crud api", "api crud", "rest api", "json api"],
        "steps": [
            step(
                "app/Models/Task.php",
                "php",
                r"""
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    protected $fillable = ['title', 'details', 'is_done'];

    protected $casts = ['is_done' => 'boolean'];
}
""",
                "The model defines fillable fields and casts the done flag to a real boolean.",
            ),
            step(
                "app/Http/Controllers/Api/TaskController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Task;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function index(): JsonResponse
    {
        return response()->json(Task::latest()->get());
    }

    public function store(Request $request): JsonResponse
    {
        $task = Task::create($request->validate([
            'title' => ['required', 'string', 'max:255'],
            'details' => ['nullable', 'string'],
            'is_done' => ['nullable', 'boolean'],
        ]));

        return response()->json($task, 201);
    }
}
""",
                "This controller returns JSON so the feature works like a real Laravel API.",
            ),
            step(
                "routes/api.php",
                "php",
                r"""
<?php

use App\Http\Controllers\Api\TaskController;
use Illuminate\Support\Facades\Route;

Route::apiResource('tasks', TaskController::class);
""",
                "The apiResource route creates clean REST endpoints for tasks.",
            ),
        ],
    },
    {
        "name": "api_auth_sanctum",
        "keywords": ["sanctum", "api auth", "api with sanctum", "token login"],
        "steps": [
            step(
                "Command Prompt",
                "bat",
                r"""
composer require laravel/sanctum
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
php artisan migrate
""",
                "These commands install Sanctum and create the personal access token tables.",
            ),
            step(
                "app/Models/User.php",
                "php",
                r"""
<?php

namespace App\Models;

use Laravel\Sanctum\HasApiTokens;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use HasApiTokens;

    protected $fillable = ['name', 'email', 'password'];

    protected function casts(): array
    {
        return ['password' => 'hashed'];
    }
}
""",
                "The HasApiTokens trait lets Laravel create and manage Sanctum tokens for the user.",
            ),
            step(
                "app/Http/Controllers/Api/AuthController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function login(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        $user = User::where('email', $validated['email'])->first();

        if (! $user || ! Hash::check($validated['password'], $user->password)) {
            return response()->json(['message' => 'Invalid credentials.'], 422);
        }

        return response()->json([
            'token' => $user->createToken('api-token')->plainTextToken,
            'user' => $user,
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()?->delete();

        return response()->json(['message' => 'Logged out successfully.']);
    }
}
""",
                "This controller creates a Sanctum token on login and deletes it on logout.",
            ),
            step(
                "routes/api.php",
                "php",
                r"""
<?php

use App\Http\Controllers\Api\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/user', fn (Request $request) => $request->user());
});
""",
                "These routes keep login public and protect the user and logout endpoints with Sanctum.",
            ),
        ],
    },
    {
        "name": "sanctum_protected_route",
        "keywords": ["protected api", "auth:sanctum", "sanctum middleware"],
        "steps": [
            step(
                "routes/api.php",
                "php",
                r"""
<?php

use App\Http\Controllers\Api\ProfileController;
use Illuminate\Support\Facades\Route;

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/profile', [ProfileController::class, 'show']);
    Route::put('/profile', [ProfileController::class, 'update']);
});
""",
                "The auth:sanctum middleware protects every route in this group with an API token.",
            ),
            step(
                "app/Http/Controllers/Api/ProfileController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function show(Request $request): JsonResponse
    {
        return response()->json($request->user());
    }
}
""",
                "This controller returns the currently authenticated API user as JSON.",
            ),
        ],
    },
    {
        "name": "validation_form_request",
        "keywords": ["validation", "form request", "validate request"],
        "steps": [
            step(
                "app/Http/Requests/StoreProductRequest.php",
                "php",
                r"""
<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'price' => ['required', 'numeric', 'min:0'],
            'description' => ['nullable', 'string', 'max:1000'],
        ];
    }
}
""",
                "A form request keeps the validation rules in one clean Laravel class.",
            ),
            step(
                "app/Http/Controllers/ProductController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreProductRequest;
use App\Models\Product;
use Illuminate\Http\RedirectResponse;

class ProductController extends Controller
{
    public function store(StoreProductRequest $request): RedirectResponse
    {
        Product::create($request->validated());

        return back()->with('success', 'Product created successfully.');
    }
}
""",
                "The controller uses validated data directly, which is simple and safe for beginners.",
            ),
        ],
    },
    {
        "name": "validation_custom_messages",
        "keywords": ["custom validation message", "validation messages", "custom rules message"],
        "steps": [
            step(
                "app/Http/Requests/StorePostRequest.php",
                "php",
                r"""
<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StorePostRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'title' => ['required', 'min:5'],
            'body' => ['required', 'min:20'],
        ];
    }

    public function messages(): array
    {
        return [
            'title.required' => 'Please enter a post title.',
            'body.min' => 'Post content must be at least 20 characters.',
        ];
    }
}
""",
                "The messages method lets you replace default Laravel validation text with beginner-friendly messages.",
            ),
            step(
                "resources/views/posts/create.blade.php",
                "blade",
                r"""
@if ($errors->any())
    <div>{{ $errors->first() }}</div>
@endif
""",
                "This Blade snippet shows the first validation error back to the user.",
            ),
        ],
    },
    {
        "name": "validation_unique_update",
        "keywords": ["unique validation update", "ignore current record", "update validation"],
        "steps": [
            step(
                "app/Http/Requests/UpdateUserRequest.php",
                "php",
                r"""
<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateUserRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => [
                'required',
                'email',
                Rule::unique('users', 'email')->ignore($this->route('user')->id),
            ],
        ];
    }
}
""",
                "This rule keeps the email unique while still allowing the current user to save the same value.",
            ),
            step(
                "app/Http/Controllers/UserController.php",
                "php",
                r"""
public function update(UpdateUserRequest $request, User $user): RedirectResponse
{
    $user->update($request->validated());

    return back()->with('success', 'Profile updated successfully.');
}
""",
                "The controller stays clean because the request class handles the difficult validation rule.",
            ),
        ],
    },
    {
        "name": "file_upload_avatar",
        "keywords": ["file upload", "avatar upload", "image upload"],
        "steps": [
            step(
                "app/Http/Controllers/ProfileController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function updateAvatar(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'avatar' => ['required', 'image', 'max:2048'],
        ]);

        $path = $validated['avatar']->store('avatars', 'public');
        $request->user()->update(['avatar' => $path]);

        return back()->with('success', 'Avatar uploaded successfully.');
    }
}
""",
                "This controller validates the image and stores it in the public disk.",
            ),
            step(
                "resources/views/profile/edit.blade.php",
                "blade",
                r"""
<form method="POST" action="{{ route('profile.avatar') }}" enctype="multipart/form-data">
    @csrf
    <input type="file" name="avatar" required>
    <button type="submit">Upload avatar</button>
</form>
""",
                "The form uses multipart encoding so Laravel can receive the uploaded file.",
            ),
        ],
    },
    {
        "name": "file_upload_document",
        "keywords": ["document upload", "pdf upload", "store file"],
        "steps": [
            step(
                "app/Http/Controllers/DocumentController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers;

use App\Models\Document;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class DocumentController extends Controller
{
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'file' => ['required', 'mimes:pdf,doc,docx', 'max:4096'],
        ]);

        $path = $validated['file']->store('documents', 'private');
        Document::create(['title' => $validated['title'], 'file_path' => $path]);

        return back()->with('success', 'Document uploaded successfully.');
    }
}
""",
                "This controller saves the uploaded document path into the database after validation.",
            ),
            step(
                "app/Models/Document.php",
                "php",
                r"""
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    protected $fillable = ['title', 'file_path'];
}
""",
                "The model lets Laravel store the document title and saved file path.",
            ),
        ],
    },
    {
        "name": "pagination_basic",
        "keywords": ["pagination", "paginate", "page links"],
        "steps": [
            step(
                "app/Http/Controllers/PostController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\View\View;

class PostController extends Controller
{
    public function index(): View
    {
        return view('posts.index', [
            'posts' => Post::latest()->paginate(10),
        ]);
    }
}
""",
                "Using paginate keeps the query fast and gives Laravel everything needed for links.",
            ),
            step(
                "resources/views/posts/index.blade.php",
                "blade",
                r"""
@foreach ($posts as $post)
    <h3>{{ $post->title }}</h3>
@endforeach

{{ $posts->links() }}
""",
                "The links method prints ready-made pagination controls in the Blade page.",
            ),
        ],
    },
    {
        "name": "pagination_api",
        "keywords": ["api pagination", "paginate api", "json pagination"],
        "steps": [
            step(
                "app/Http/Controllers/Api/PostController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PostResource;
use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function index(Request $request)
    {
        $posts = Post::latest()->paginate($request->integer('per_page', 15));

        return PostResource::collection($posts);
    }
}
""",
                "This API controller returns paginated data and still keeps the JSON response clean.",
            ),
            step(
                "app/Http/Resources/PostResource.php",
                "php",
                r"""
<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PostResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'body' => $this->body,
        ];
    }
}
""",
                "The resource controls which post fields appear in the paginated API response.",
            ),
        ],
    },
    {
        "name": "blade_layout",
        "keywords": ["blade layout", "layout", "master blade"],
        "steps": [
            step(
                "resources/views/layouts/app.blade.php",
                "blade",
                r"""
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Laravel App')</title>
</head>
<body>
    <nav><a href="{{ route('dashboard') }}">Dashboard</a></nav>
    <main>@yield('content')</main>
</body>
</html>
""",
                "This layout keeps common HTML in one reusable Blade file.",
            ),
            step(
                "resources/views/dashboard.blade.php",
                "blade",
                r"""
@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    <h1>Laravel Dashboard</h1>
@endsection
""",
                "The dashboard extends the layout so the page stays consistent with the rest of the app.",
            ),
        ],
    },
    {
        "name": "blade_component_alert",
        "keywords": ["blade component", "alert component", "ui component"],
        "steps": [
            step(
                "resources/views/components/alert.blade.php",
                "blade",
                r"""
<div class="alert alert-{{ $type }}">
    {{ $slot }}
</div>
""",
                "This component lets you reuse the same alert HTML anywhere in your Blade views.",
            ),
            step(
                "resources/views/posts/index.blade.php",
                "blade",
                r"""
@if (session('success'))
    <x-alert type="success">{{ session('success') }}</x-alert>
@endif
""",
                "The component call keeps the view shorter and easier to understand.",
            ),
        ],
    },
    {
        "name": "blade_dashboard_ui",
        "keywords": ["blade ui", "dashboard ui", "blade dashboard"],
        "steps": [
            step(
                "routes/web.php",
                "php",
                r"""
<?php

use Illuminate\Support\Facades\Route;

Route::get('/dashboard', function () {
    return view('dashboard', [
        'stats' => [
            'products' => 12,
            'orders' => 5,
            'users' => 30,
        ],
    ]);
})->name('dashboard');
""",
                "This route passes simple dashboard data directly into the view.",
            ),
            step(
                "resources/views/dashboard.blade.php",
                "blade",
                r"""
@extends('layouts.app')

@section('content')
    <h1>Dashboard</h1>
    <ul>
        <li>Total products: {{ $stats['products'] }}</li>
        <li>Total orders: {{ $stats['orders'] }}</li>
        <li>Total users: {{ $stats['users'] }}</li>
    </ul>
@endsection
""",
                "This Blade page prints dashboard totals in a beginner-friendly UI.",
            ),
        ],
    },
    {
        "name": "blade_form_old_input",
        "keywords": ["old input", "blade form", "keep old values"],
        "steps": [
            step(
                "resources/views/products/create.blade.php",
                "blade",
                r"""
<form method="POST" action="{{ route('products.store') }}">
    @csrf
    <input type="text" name="name" value="{{ old('name') }}" placeholder="Product name">
    <textarea name="description">{{ old('description') }}</textarea>
    <button type="submit">Save</button>
</form>
""",
                "The old helper keeps the user input in the form after validation fails.",
            ),
            step(
                "app/Http/Controllers/ProductController.php",
                "php",
                r"""
if ($validator->fails()) {
    return back()->withErrors($validator)->withInput();
}
""",
                "withInput sends the previous form values back to the Blade view.",
            ),
        ],
    },
    {
        "name": "migration_create_products",
        "keywords": ["migration", "create table", "product migration"],
        "steps": [
            step(
                "database/migrations/2026_01_01_000010_create_products_table.php",
                "php",
                r"""
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->decimal('price', 10, 2);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
""",
                "This migration is the standard Laravel way to create a new database table.",
            ),
            step(
                "Command Prompt",
                "bat",
                r"""
php artisan migrate
""",
                "Run migrate to create the table in your project database.",
            ),
        ],
    },
    {
        "name": "migration_add_status",
        "keywords": ["add column", "status column", "alter table migration"],
        "steps": [
            step(
                "database/migrations/2026_01_01_000011_add_status_to_products_table.php",
                "php",
                r"""
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('status')->default('draft')->after('price');
        });
    }

    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropColumn('status');
        });
    }
};
""",
                "This migration adds a new status field without rebuilding the whole table.",
            ),
            step(
                "app/Models/Product.php",
                "php",
                r"""
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = ['name', 'price', 'status'];
}
""",
                "The model includes the new field so Laravel can save it correctly.",
            ),
        ],
    },
    {
        "name": "seeder_admin_user",
        "keywords": ["seeder", "admin user", "seed admin"],
        "steps": [
            step(
                "database/seeders/AdminUserSeeder.php",
                "php",
                r"""
<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        User::updateOrCreate(
            ['email' => 'admin@example.com'],
            ['name' => 'Admin', 'password' => 'password', 'is_admin' => true]
        );
    }
}
""",
                "This seeder makes sure your admin user exists every time you seed the database.",
            ),
            step(
                "database/seeders/DatabaseSeeder.php",
                "php",
                r"""
<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(AdminUserSeeder::class);
    }
}
""",
                "Registering the seeder here lets php artisan db:seed run it automatically.",
            ),
        ],
    },
    {
        "name": "factory_product",
        "keywords": ["factory", "product factory", "fake data"],
        "steps": [
            step(
                "database/factories/ProductFactory.php",
                "php",
                r"""
<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class ProductFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name' => fake()->words(3, true),
            'price' => fake()->randomFloat(2, 10, 500),
            'description' => fake()->sentence(),
        ];
    }
}
""",
                "The factory generates realistic fake product data for testing and seeding.",
            ),
            step(
                "database/seeders/ProductSeeder.php",
                "php",
                r"""
<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        Product::factory()->count(20)->create();
    }
}
""",
                "This seeder fills the products table with sample data in one line.",
            ),
        ],
    },
    {
        "name": "observer_slug",
        "keywords": ["observer", "slug observer", "auto slug"],
        "steps": [
            step(
                "app/Observers/PostObserver.php",
                "php",
                r"""
<?php

namespace App\Observers;

use App\Models\Post;
use Illuminate\Support\Str;

class PostObserver
{
    public function creating(Post $post): void
    {
        $post->slug = Str::slug($post->title);
    }
}
""",
                "The observer creates a slug automatically before the post is saved.",
            ),
            step(
                "app/Providers/AppServiceProvider.php",
                "php",
                r"""
<?php

namespace App\Providers;

use App\Models\Post;
use App\Observers\PostObserver;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        Post::observe(PostObserver::class);
    }
}
""",
                "Registering the observer in the service provider turns it on for the model.",
            ),
        ],
    },
    {
        "name": "scope_published",
        "keywords": ["scope", "published scope", "model scope"],
        "steps": [
            step(
                "app/Models/Post.php",
                "php",
                r"""
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    public function scopePublished(Builder $query): void
    {
        $query->where('status', 'published');
    }
}
""",
                "A local scope lets you reuse the same published filter in many places.",
            ),
            step(
                "app/Http/Controllers/PostController.php",
                "php",
                r"""
$posts = Post::published()->latest()->get();
""",
                "Calling the scope keeps your controller query short and easy to read.",
            ),
        ],
    },
    {
        "name": "soft_deletes",
        "keywords": ["soft delete", "soft deletes", "trash records"],
        "steps": [
            step(
                "database/migrations/2026_01_01_000012_add_soft_deletes_to_posts_table.php",
                "php",
                r"""
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('posts', function (Blueprint $table) {
            $table->softDeletes();
        });
    }
};
""",
                "softDeletes adds the deleted_at column Laravel needs for soft delete support.",
            ),
            step(
                "app/Models/Post.php",
                "php",
                r"""
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Post extends Model
{
    use SoftDeletes;
}
""",
                "The SoftDeletes trait tells Laravel to hide deleted rows from normal queries.",
            ),
        ],
    },
    {
        "name": "route_model_binding",
        "keywords": ["route model binding", "model binding", "bound model"],
        "steps": [
            step(
                "routes/web.php",
                "php",
                r"""
<?php

use App\Http\Controllers\PostController;
use Illuminate\Support\Facades\Route;

Route::get('/posts/{post}', [PostController::class, 'show'])->name('posts.show');
""",
                "Laravel automatically loads the Post model because the route parameter name matches the controller type hint.",
            ),
            step(
                "app/Http/Controllers/PostController.php",
                "php",
                r"""
public function show(Post $post): View
{
    return view('posts.show', compact('post'));
}
""",
                "Type-hinting the model removes manual find logic from the controller.",
            ),
        ],
    },
    {
        "name": "user_posts_relationship",
        "keywords": ["has many", "user posts", "relationship hasmany"],
        "steps": [
            step(
                "app/Models/User.php",
                "php",
                r"""
public function posts()
{
    return $this->hasMany(Post::class);
}
""",
                "This relationship lets Laravel load all posts that belong to a user.",
            ),
            step(
                "app/Models/Post.php",
                "php",
                r"""
public function user()
{
    return $this->belongsTo(User::class);
}
""",
                "The inverse relationship lets each post access the owner user.",
            ),
        ],
    },
    {
        "name": "post_tags_many_to_many",
        "keywords": ["many to many", "tags", "post tags", "pivot table"],
        "steps": [
            step(
                "database/migrations/2026_01_01_000013_create_post_tag_table.php",
                "php",
                r"""
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('post_tag', function (Blueprint $table) {
            $table->foreignId('post_id')->constrained()->cascadeOnDelete();
            $table->foreignId('tag_id')->constrained()->cascadeOnDelete();
            $table->primary(['post_id', 'tag_id']);
        });
    }
};
""",
                "The pivot table stores the many-to-many link between posts and tags.",
            ),
            step(
                "app/Models/Post.php",
                "php",
                r"""
public function tags()
{
    return $this->belongsToMany(Tag::class);
}
""",
                "belongsToMany gives the Post model access to every related tag.",
            ),
        ],
    },
    {
        "name": "eager_loading_posts_comments",
        "keywords": ["eager loading", "with comments", "n+1"],
        "steps": [
            step(
                "app/Http/Controllers/PostController.php",
                "php",
                r"""
$posts = Post::with(['user', 'comments'])->latest()->get();
""",
                "with loads the related models early and helps avoid the N+1 query problem.",
            ),
            step(
                "resources/views/posts/index.blade.php",
                "blade",
                r"""
@foreach ($posts as $post)
    <h3>{{ $post->title }}</h3>
    <p>By {{ $post->user->name }}</p>
    <p>Total comments: {{ $post->comments->count() }}</p>
@endforeach
""",
                "The view can now use the loaded relationships without extra database queries.",
            ),
        ],
    },
    {
        "name": "search_posts",
        "keywords": ["search", "post search", "search filter"],
        "steps": [
            step(
                "app/Http/Controllers/PostController.php",
                "php",
                r"""
public function index(Request $request): View
{
    $search = $request->string('search');

    $posts = Post::query()
        ->when($search, fn ($query) => $query->where('title', 'like', "%{$search}%"))
        ->latest()
        ->get();

    return view('posts.index', compact('posts', 'search'));
}
""",
                "The when method adds the search filter only when the user types a value.",
            ),
            step(
                "resources/views/posts/index.blade.php",
                "blade",
                r"""
<form method="GET" action="{{ route('posts.index') }}">
    <input type="text" name="search" value="{{ $search }}" placeholder="Search posts">
    <button type="submit">Search</button>
</form>
""",
                "This GET form sends the search text back to the same index page.",
            ),
        ],
    },
    {
        "name": "filter_status_query",
        "keywords": ["status filter", "query filter", "filter by status"],
        "steps": [
            step(
                "app/Http/Controllers/ProductController.php",
                "php",
                r"""
$status = $request->string('status');

$products = Product::query()
    ->when($status, fn ($query) => $query->where('status', $status))
    ->latest()
    ->get();
""",
                "This query applies the status filter only when the user selects one.",
            ),
            step(
                "resources/views/products/index.blade.php",
                "blade",
                r"""
<select name="status">
    <option value="">All</option>
    <option value="draft">Draft</option>
    <option value="published">Published</option>
</select>
""",
                "A simple select box is enough to let beginners test the status filter.",
            ),
        ],
    },
    {
        "name": "api_resource_post",
        "keywords": ["api resource", "json resource", "single resource"],
        "steps": [
            step(
                "app/Http/Resources/PostResource.php",
                "php",
                r"""
<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PostResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'author' => $this->user?->name,
            'created_at' => $this->created_at?->toDateTimeString(),
        ];
    }
}
""",
                "A resource lets you control the exact JSON shape for a single post response.",
            ),
            step(
                "app/Http/Controllers/Api/PostController.php",
                "php",
                r"""
public function show(Post $post): PostResource
{
    return new PostResource($post->load('user'));
}
""",
                "The controller returns the resource instead of raw model data for cleaner APIs.",
            ),
        ],
    },
    {
        "name": "api_resource_collection",
        "keywords": ["resource collection", "json collection", "collection resource"],
        "steps": [
            step(
                "app/Http/Resources/PostCollection.php",
                "php",
                r"""
<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\ResourceCollection;

class PostCollection extends ResourceCollection
{
    public function toArray(Request $request): array
    {
        return [
            'data' => PostResource::collection($this->collection),
        ];
    }
}
""",
                "A collection resource keeps the API response format consistent for list endpoints.",
            ),
            step(
                "app/Http/Controllers/Api/PostController.php",
                "php",
                r"""
public function index(): PostCollection
{
    return new PostCollection(Post::with('user')->latest()->get());
}
""",
                "The controller now returns a dedicated collection object instead of a raw array.",
            ),
        ],
    },
    {
        "name": "policy_update_post",
        "keywords": ["policy", "authorize update", "post policy"],
        "steps": [
            step(
                "app/Policies/PostPolicy.php",
                "php",
                r"""
<?php

namespace App\Policies;

use App\Models\Post;
use App\Models\User;

class PostPolicy
{
    public function update(User $user, Post $post): bool
    {
        return $user->id === $post->user_id;
    }
}
""",
                "This policy allows only the owner of the post to update it.",
            ),
            step(
                "app/Http/Controllers/PostController.php",
                "php",
                r"""
public function edit(Post $post): View
{
    $this->authorize('update', $post);

    return view('posts.edit', compact('post'));
}
""",
                "Calling authorize inside the controller applies the policy before the page opens.",
            ),
        ],
    },
    {
        "name": "gate_manage_users",
        "keywords": ["gate", "manage users", "authorization gate"],
        "steps": [
            step(
                "app/Providers/AppServiceProvider.php",
                "php",
                r"""
<?php

namespace App\Providers;

use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        Gate::define('manage-users', fn ($user) => $user->is_admin);
    }
}
""",
                "The gate defines one reusable authorization rule for user management screens.",
            ),
            step(
                "routes/web.php",
                "php",
                r"""
Route::get('/users', fn () => view('users.index'))
    ->middleware(['auth', 'can:manage-users'])
    ->name('users.index');
""",
                "The can middleware checks the gate before the route runs.",
            ),
        ],
    },
    {
        "name": "queue_send_report_job",
        "keywords": ["queue job", "job", "dispatch job"],
        "steps": [
            step(
                "app/Jobs/SendReportJob.php",
                "php",
                r"""
<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendReportJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(public int $reportId)
    {
    }

    public function handle(): void
    {
        // Generate and send the report here.
    }
}
""",
                "This job moves slow report work into Laravel queues so the request stays fast.",
            ),
            step(
                "app/Http/Controllers/ReportController.php",
                "php",
                r"""
use App\Jobs\SendReportJob;

SendReportJob::dispatch($report->id);
""",
                "Dispatching the job sends the heavy task to the queue worker.",
            ),
        ],
    },
    {
        "name": "event_order_created",
        "keywords": ["event", "order created event", "dispatch event"],
        "steps": [
            step(
                "app/Events/OrderCreated.php",
                "php",
                r"""
<?php

namespace App\Events;

use App\Models\Order;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class OrderCreated
{
    use Dispatchable, SerializesModels;

    public function __construct(public Order $order)
    {
    }
}
""",
                "The event carries the new order so other parts of the app can react to it.",
            ),
            step(
                "app/Http/Controllers/OrderController.php",
                "php",
                r"""
use App\Events\OrderCreated;

OrderCreated::dispatch($order);
""",
                "Dispatching the event keeps your controller clean and opens the door for listeners later.",
            ),
        ],
    },
    {
        "name": "listener_send_invoice",
        "keywords": ["listener", "event listener", "send invoice listener"],
        "steps": [
            step(
                "app/Listeners/SendInvoiceEmail.php",
                "php",
                r"""
<?php

namespace App\Listeners;

use App\Events\OrderCreated;
use App\Mail\InvoiceMail;
use Illuminate\Support\Facades\Mail;

class SendInvoiceEmail
{
    public function handle(OrderCreated $event): void
    {
        Mail::to($event->order->customer_email)->send(new InvoiceMail($event->order));
    }
}
""",
                "The listener reacts to the event and sends the invoice email in one place.",
            ),
            step(
                "app/Providers/EventServiceProvider.php",
                "php",
                r"""
<?php

namespace App\Providers;

use App\Events\OrderCreated;
use App\Listeners\SendInvoiceEmail;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    protected $listen = [
        OrderCreated::class => [
            SendInvoiceEmail::class,
        ],
    ];
}
""",
                "Registering the listener tells Laravel which class should handle the event.",
            ),
        ],
    },
    {
        "name": "notification_database",
        "keywords": ["notification", "database notification", "notify user"],
        "steps": [
            step(
                "app/Notifications/OrderShippedNotification.php",
                "php",
                r"""
<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class OrderShippedNotification extends Notification
{
    use Queueable;

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'message' => 'Your order has been shipped.',
        ];
    }
}
""",
                "This notification stores a simple message in the notifications table.",
            ),
            step(
                "app/Http/Controllers/OrderController.php",
                "php",
                r"""
$request->user()->notify(new OrderShippedNotification());
""",
                "notify sends the notification to the current user with one simple call.",
            ),
        ],
    },
    {
        "name": "mail_welcome_user",
        "keywords": ["mail", "welcome email", "mailable"],
        "steps": [
            step(
                "app/Mail/WelcomeUserMail.php",
                "php",
                r"""
<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class WelcomeUserMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public User $user)
    {
    }

    public function build(): self
    {
        return $this->subject('Welcome')->view('emails.welcome');
    }
}
""",
                "The mailable class holds the subject and Blade view for the email.",
            ),
            step(
                "app/Http/Controllers/AuthController.php",
                "php",
                r"""
use App\Mail\WelcomeUserMail;
use Illuminate\Support\Facades\Mail;

Mail::to($user->email)->send(new WelcomeUserMail($user));
""",
                "Sending the welcome email right after registration is simple with Laravel Mail.",
            ),
        ],
    },
    {
        "name": "schedule_daily_cleanup",
        "keywords": ["scheduler", "schedule", "daily cleanup"],
        "steps": [
            step(
                "app/Console/Kernel.php",
                "php",
                r"""
<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    protected function schedule(Schedule $schedule): void
    {
        $schedule->command('reports:cleanup')->dailyAt('01:00');
    }
}
""",
                "The schedule method tells Laravel when the cleanup command should run every day.",
            ),
            step(
                "Command Prompt",
                "bat",
                r"""
php artisan schedule:work
""",
                "schedule:work keeps the scheduler running in your local environment.",
            ),
        ],
    },
    {
        "name": "artisan_cleanup_command",
        "keywords": ["artisan command", "custom command", "cleanup command"],
        "steps": [
            step(
                "app/Console/Commands/CleanupReports.php",
                "php",
                r"""
<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class CleanupReports extends Command
{
    protected $signature = 'reports:cleanup';

    protected $description = 'Delete old generated reports';

    public function handle(): int
    {
        $this->info('Old reports cleaned successfully.');

        return self::SUCCESS;
    }
}
""",
                "This command gives you a reusable Laravel task that can run from CMD or the scheduler.",
            ),
            step(
                "Command Prompt",
                "bat",
                r"""
php artisan reports:cleanup
""",
                "Running the command manually helps you test it before scheduling it.",
            ),
        ],
    },
    {
        "name": "cache_dashboard_stats",
        "keywords": ["cache", "dashboard cache", "remember cache"],
        "steps": [
            step(
                "app/Http/Controllers/DashboardController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use Illuminate\Support\Facades\Cache;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): View
    {
        $stats = Cache::remember('dashboard.stats', 300, function () {
            return [
                'products' => Product::count(),
                'orders' => Order::count(),
            ];
        });

        return view('dashboard', compact('stats'));
    }
}
""",
                "Cache::remember stores expensive counts for five minutes to speed up repeat visits.",
            ),
            step(
                "Command Prompt",
                "bat",
                r"""
php artisan cache:clear
""",
                "Use cache:clear when you need to remove old cached values during testing.",
            ),
        ],
    },
    {
        "name": "session_flash_message",
        "keywords": ["flash message", "session message", "success message"],
        "steps": [
            step(
                "app/Http/Controllers/ProductController.php",
                "php",
                r"""
return redirect()->route('products.index')->with('success', 'Product saved successfully.');
""",
                "with stores a one-time flash message in the session for the next request.",
            ),
            step(
                "resources/views/products/index.blade.php",
                "blade",
                r"""
@if (session('success'))
    <div>{{ session('success') }}</div>
@endif
""",
                "This Blade block prints the success message after the redirect.",
            ),
        ],
    },
    {
        "name": "localization_messages",
        "keywords": ["localization", "translation", "lang file"],
        "steps": [
            step(
                "lang/en/messages.php",
                "php",
                r"""
<?php

return [
    'welcome' => 'Welcome back to your Laravel dashboard.',
];
""",
                "Language files keep your text in one place so it is easy to translate later.",
            ),
            step(
                "resources/views/dashboard.blade.php",
                "blade",
                r"""
<p>{{ __('messages.welcome') }}</p>
""",
                "The __ helper loads the translated message from the language file.",
            ),
        ],
    },
    {
        "name": "storage_link_public",
        "keywords": ["storage link", "public storage", "show uploaded image"],
        "steps": [
            step(
                "Command Prompt",
                "bat",
                r"""
php artisan storage:link
""",
                "This command creates the public storage shortcut Laravel needs for browser access.",
            ),
            step(
                "resources/views/profile/show.blade.php",
                "blade",
                r"""
<img src="{{ asset('storage/' . $user->avatar) }}" alt="Avatar">
""",
                "asset(storage/...) builds a browser URL for the file stored on the public disk.",
            ),
        ],
    },
    {
        "name": "throttle_api_routes",
        "keywords": ["throttle", "rate limit", "api throttle"],
        "steps": [
            step(
                "app/Providers/RouteServiceProvider.php",
                "php",
                r"""
<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;

class RouteServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        RateLimiter::for('api', fn (Request $request) => Limit::perMinute(60)->by($request->user()?->id ?: $request->ip()));
    }
}
""",
                "This rate limiter protects your API from too many requests in a short time.",
            ),
            step(
                "routes/api.php",
                "php",
                r"""
Route::middleware('throttle:api')->get('/stats', fn () => ['status' => 'ok']);
""",
                "Applying the throttle middleware activates the limiter on this route.",
            ),
        ],
    },
    {
        "name": "transaction_order_checkout",
        "keywords": ["transaction", "database transaction", "checkout transaction"],
        "steps": [
            step(
                "app/Http/Controllers/CheckoutController.php",
                "php",
                r"""
<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CheckoutController extends Controller
{
    public function store(Request $request): RedirectResponse
    {
        DB::transaction(function () use ($request) {
            $order = Order::create(['user_id' => $request->user()->id, 'total' => 150]);

            OrderItem::create([
                'order_id' => $order->id,
                'product_id' => 1,
                'quantity' => 1,
                'price' => 150,
            ]);
        });

        return redirect()->route('orders.index')->with('success', 'Order placed successfully.');
    }
}
""",
                "A transaction makes sure the order and order item are saved together or rolled back together.",
            ),
            step(
                "routes/web.php",
                "php",
                r"""
Route::post('/checkout', [CheckoutController::class, 'store'])->middleware('auth')->name('checkout.store');
""",
                "This route keeps checkout behind login and sends the request to the transaction code.",
            ),
        ],
    },
]


output_path = DATASET_DIR / "mini_ai.json"
payload = {"entries": entries}
output_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
print(f"Wrote {len(entries)} Laravel features to {output_path}")
