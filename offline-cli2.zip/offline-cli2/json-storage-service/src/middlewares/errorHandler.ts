import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

export const errorHandler = (err: Error, req: Request, res: Response, next: NextFunction) => {
  logger.error(`Unhandled error at ${req.method} ${req.url}`, err);

  if (err.message === 'Data file corrupted or unreadable') {
    return res.status(500).json({
      error: 'Internal Server Error',
      message: 'The underlying data source is corrupted.'
    });
  }

  res.status(500).json({
    error: 'Internal Server Error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'An unexpected error occurred'
  });
};
