OPENAI_API_KEY = "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"
OPENAI_MODEL = "gpt-5"
OPENAI_API_URL = "https://api.openai.com/v1/responses"
OPENAI_MAX_OUTPUT_TOKENS = 1800

ANTHROPIC_API_KEY = "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"
ANTHROPIC_MODEL = "claude-sonnet-4-20250514"
ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_API_VERSION = "2023-06-01"
ANTHROPIC_MAX_OUTPUT_TOKENS = 1800

GROQ_API_KEY = "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"
GROQ_MODEL = "llama-3.3-70b-versatile"
GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_TEMPERATURE = 0.2

MINI_AI_FILE = "dataset/mini_ai.json"
LOCAL_MODEL_PATH = "local/main.exe"
LOCAL_MODEL_FILE = "local/model.gguf"

REQUEST_TIMEOUT_SECONDS = 60
LOCAL_TIMEOUT_SECONDS = 120
LOCAL_MAX_OUTPUT_TOKENS = 1200

CACHE_ENABLED = True
CACHE_FALLBACK_RESPONSES = False
CACHE_DIR = "cache"
HISTORY_FILE = "history/commands.log"
FALLBACK_LOG_FILE = "logs/fallback.log"
LAST_OUTPUT_FILE = "history/last_output.json"

DATASET_AUTO_LEARN_ENABLED = True
PROMPT_TO_APPLY_FILES = False
